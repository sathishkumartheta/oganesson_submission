package com.example.cityinsightmaps.models;
import com.google.firebase.firestore.GeoPoint;
import java.util.List;
import java.util.Date;

public class CulturalPoliticalEvent {
    private String id;
    private GeoPoint location;
    private String name;
    private String type; // e.g., "Festival", "Protest", "Election", "UserReported"
    private String description;
    private Date startTime;
    private Date endTime;
    private String imageUrl; // NEW: URL for uploaded image
    private String videoUrl; // NEW: URL for uploaded video
    private String userId; // NEW: ID of the user who reported it

    public CulturalPoliticalEvent() {}

    public CulturalPoliticalEvent(String id, GeoPoint location, String name, String type, String description,
                                  Date startTime, Date endTime, String imageUrl, String videoUrl, String userId) {
        this.id = id;
        this.location = location;
        this.name = name;
        this.type = type;
        this.description = description;
        this.startTime = startTime;
        this.endTime = endTime;
        this.imageUrl = imageUrl;
        this.videoUrl = videoUrl;
        this.userId = userId;
    }

    // Getters and Setters (add for new fields)
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public GeoPoint getLocation() { return location; }
    public void setLocation(GeoPoint location) { this.location = location; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getType() { return type; }
    public void setType(String type) { this.type = type; }
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
    public Date getStartTime() { return startTime; }
    public void setStartTime(Date startTime) { this.startTime = startTime; }
    public Date getEndTime() { return endTime; }
    public void setEndTime(Date endTime) { this.endTime = endTime; }
    public String getImageUrl() { return imageUrl; } // NEW
    public void setImageUrl(String imageUrl) { this.imageUrl = imageUrl; } // NEW
    public String getVideoUrl() { return videoUrl; } // NEW
    public void setVideoUrl(String videoUrl) { this.videoUrl = videoUrl; } // NEW
    public String getUserId() { return userId; } // NEW
    public void setUserId(String userId) { this.userId = userId; } // NEW

}
