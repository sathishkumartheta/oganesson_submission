package com.example.cityinsightmaps;
import android.app.Application;
import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Address;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.GeoPoint;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.bumptech.glide.Glide; // For loading image previews (add dependency for Glide)
import com.example.cityinsightmaps.models.CulturalPoliticalEvent; // Import your updated model

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
public class UploadEventActivity extends AppCompatActivity{
    private static final String TAG = "UploadEventActivity";

    private ImageView imageViewPreview;
    private Button buttonSelectImage, buttonSelectVideo, buttonUploadEvent;
    private EditText editTextEventName, editTextEventDescription, editTextEventType, editTextLocation;
    private ProgressBar progressBarUpload;

    private Uri selectedImageUri;
    private Uri selectedVideoUri;

    private FirebaseAuth mAuth;
    private FirebaseFirestore db;
    private FirebaseStorage storage;
    private StorageReference storageReference;

    // ActivityResultLaunchers for picking media and requesting permissions
    private ActivityResultLauncher<String> requestPermissionLauncher;
    private ActivityResultLauncher<Intent> pickImageLauncher;
    private ActivityResultLauncher<Intent> pickVideoLauncher;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_upload_event);

        mAuth = FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance();
        storage = FirebaseStorage.getInstance();
        storageReference = storage.getReference();

        // Initialize UI elements
        imageViewPreview = findViewById(R.id.imageViewPreview);
        buttonSelectImage = findViewById(R.id.buttonSelectImage);
        buttonSelectVideo = findViewById(R.id.buttonSelectVideo);
        buttonUploadEvent = findViewById(R.id.buttonUploadEvent);
        editTextEventName = findViewById(R.id.editTextEventName);
        editTextEventDescription = findViewById(R.id.editTextEventDescription);
        editTextEventType = findViewById(R.id.editTextEventType);
        editTextLocation = findViewById(R.id.editTextLocation);
        progressBarUpload = findViewById(R.id.progressBarUpload);

        // Initialize ActivityResultLaunchers
        requestPermissionLauncher = registerForActivityResult(new ActivityResultContracts.RequestPermission(), isGranted -> {
            if (isGranted) {
                // Permission granted, proceed with media selection
                Toast.makeText(this, "Storage permission granted.", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Storage permission denied. Cannot select media.", Toast.LENGTH_LONG).show();
            }
        });

        pickImageLauncher = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), result -> {
            if (result.getResultCode() == RESULT_OK && result.getData() != null) {
                selectedImageUri = result.getData().getData();
                if (selectedImageUri != null) {
                    // Display image preview using Glide
                    Glide.with(this).load(selectedImageUri).into(imageViewPreview);
                    selectedVideoUri = null; // Clear video selection if image is chosen
                    Toast.makeText(this, "Image selected.", Toast.LENGTH_SHORT).show();
                }
            }
        });

        pickVideoLauncher = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), result -> {
            if (result.getResultCode() == RESULT_OK && result.getData() != null) {
                selectedVideoUri = result.getData().getData();
                if (selectedVideoUri != null) {
                    // For video, you might want to show a video thumbnail or a generic video icon
                    imageViewPreview.setImageResource(android.R.drawable.presence_video_online); // Generic video icon
                    selectedImageUri = null; // Clear image selection if video is chosen
                    Toast.makeText(this, "Video selected.", Toast.LENGTH_SHORT).show();
                }
            }
        });


        // Set click listeners
        buttonSelectImage.setOnClickListener(v -> checkPermissionAndPickMedia("image"));
        buttonSelectVideo.setOnClickListener(v -> checkPermissionAndPickMedia("video"));
        buttonUploadEvent.setOnClickListener(v -> uploadEvent());
    }

    private void checkPermissionAndPickMedia(String mediaType) {
        String permission;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            // For Android 13 (API 33) and above, use specific media permissions
            if (mediaType.equals("image")) {
                permission = Manifest.permission.READ_MEDIA_IMAGES;
            } else { // video
                permission = Manifest.permission.READ_MEDIA_VIDEO;
            }
        } else {
            // For Android 12 (API 32) and below, use READ_EXTERNAL_STORAGE
            permission = Manifest.permission.READ_EXTERNAL_STORAGE;
        }

        if (ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED) {
            if (mediaType.equals("image")) {
                pickImage();
            } else {
                pickVideo();
            }
        } else {
            requestPermissionLauncher.launch(permission);
        }
    }


    private void pickImage() {
        Intent intent = new Intent(Intent.ACTION_PICK);
        intent.setType("image/*");
        pickImageLauncher.launch(intent);
    }

    private void pickVideo() {
        Intent intent = new Intent(Intent.ACTION_PICK);
        intent.setType("video/*");
        pickVideoLauncher.launch(intent);
    }

    private void uploadEvent() {
        String eventName = editTextEventName.getText().toString().trim();
        String eventDescription = editTextEventDescription.getText().toString().trim();
        String eventType = editTextEventType.getText().toString().trim();
        String locationText = editTextLocation.getText().toString().trim();

        if (TextUtils.isEmpty(eventName) || TextUtils.isEmpty(eventDescription) ||
                TextUtils.isEmpty(eventType) || TextUtils.isEmpty(locationText)) {
            Toast.makeText(this, "Please fill all event details.", Toast.LENGTH_SHORT).show();
            return;
        }

        if (selectedImageUri == null && selectedVideoUri == null) {
            Toast.makeText(this, "Please select an image or video for the event.", Toast.LENGTH_SHORT).show();
            return;
        }

        progressBarUpload.setVisibility(View.VISIBLE);
        buttonUploadEvent.setEnabled(false); // Disable button during upload

        FirebaseUser currentUser = mAuth.getCurrentUser();
        if (currentUser == null) {
            Toast.makeText(this, "User not authenticated. Please log in.", Toast.LENGTH_SHORT).show();
            progressBarUpload.setVisibility(View.GONE);
            buttonUploadEvent.setEnabled(true);
            return;
        }

        // Geocode the location text to LatLng
        // Note: For production, consider using Google Places API for more robust location input
        // For simplicity, we'll use Android's Geocoder here.
        new Thread(() -> {
            try {
                android.location.Geocoder geocoder = new android.location.Geocoder(this, Locale.getDefault());
                List<Address> addresses = geocoder.getFromLocationName(locationText, 1);
                if (addresses != null && !addresses.isEmpty()) {
                    android.location.Address address = addresses.get(0);
                    GeoPoint geoPoint = new GeoPoint(address.getLatitude(), address.getLongitude());

                    // Proceed with upload on the UI thread
                    runOnUiThread(() -> uploadMediaAndEventToFirestore(eventName, eventDescription, eventType, geoPoint, currentUser.getUid()));

                } else {
                    runOnUiThread(() -> {
                        Toast.makeText(this, "Could not find coordinates for the entered location.", Toast.LENGTH_LONG).show();
                        progressBarUpload.setVisibility(View.GONE);
                        buttonUploadEvent.setEnabled(true);
                    });
                }
            } catch (IOException e) {
                Log.e(TAG, "Geocoding error: " + e.getMessage());
                runOnUiThread(() -> {
                    Toast.makeText(this, "Geocoding error: " + e.getMessage(), Toast.LENGTH_LONG).show();
                    progressBarUpload.setVisibility(View.GONE);
                    buttonUploadEvent.setEnabled(true);
                });
            }
        }).start();
    }

    private void uploadMediaAndEventToFirestore(String eventName, String eventDescription, String eventType, GeoPoint geoPoint, String userId) {
        String mediaFileName = UUID.randomUUID().toString(); // Unique file name
        StorageReference fileRef;
        Uri mediaUriToUpload;
        String mediaTypeForStorage; // "images" or "videos"

        if (selectedImageUri != null) {
            fileRef = storageReference.child("event_media/images/" + mediaFileName + ".jpg");
            mediaUriToUpload = selectedImageUri;
            mediaTypeForStorage = "image";
        } else { // selectedVideoUri != null
            fileRef = storageReference.child("event_media/videos/" + mediaFileName + ".mp4");
            mediaUriToUpload = selectedVideoUri;
            mediaTypeForStorage = "video";
        }

        fileRef.putFile(mediaUriToUpload)
                .addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                    @Override
                    public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                        fileRef.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                            @Override
                            public void onSuccess(Uri uri) {
                                String downloadUrl = uri.toString();
                                saveEventToFirestore(eventName, eventDescription, eventType, geoPoint, userId, downloadUrl, mediaTypeForStorage);
                            }
                        }).addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {
                                progressBarUpload.setVisibility(View.GONE);
                                buttonUploadEvent.setEnabled(true);
                                Toast.makeText(UploadEventActivity.this, "Failed to get download URL: " + e.getMessage(), Toast.LENGTH_LONG).show();
                                Log.e(TAG, "Failed to get download URL", e);
                            }
                        });
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        progressBarUpload.setVisibility(View.GONE);
                        buttonUploadEvent.setEnabled(true);
                        Toast.makeText(UploadEventActivity.this, "Media upload failed: " + e.getMessage(), Toast.LENGTH_LONG).show();
                        Log.e(TAG, "Media upload failed", e);
                    }
                })
                .addOnProgressListener(snapshot -> {
                    double progress = (100.0 * snapshot.getBytesTransferred() / snapshot.getTotalByteCount());
                    progressBarUpload.setProgress((int) progress);
                });
    }

    private void saveEventToFirestore(String eventName, String eventDescription, String eventType, GeoPoint geoPoint, String userId, String mediaUrl, String mediaTypeForStorage) {
        Map<String, Object> eventData = new HashMap<>();

        eventData.put("description", eventDescription);
        eventData.put("type", "UserReported - " + eventType); // Differentiate user-reported events
        eventData.put("location", geoPoint);
        eventData.put("name", eventName);
        eventData.put("timestamp", System.currentTimeMillis());
        eventData.put("userId", userId);
        if (mediaTypeForStorage.equals("image")) {
            eventData.put("imageUrl", mediaUrl);
            eventData.put("videoUrl", null); // Ensure only one is set
        } else {
            eventData.put("videoUrl", mediaUrl);
            eventData.put("imageUrl", null); // Ensure only one is set
        }


        // Save to 'cultural_political_events' or a new collection like 'user_reported_events'
        // For simplicity, we'll add to 'cultural_political_events' for now,
        // but mark it with a distinct type "UserReported - [original type]"
        db.collection("raw_user_data")
                .add(eventData)
                .addOnSuccessListener(documentReference -> {
                    progressBarUpload.setVisibility(View.GONE);
                    buttonUploadEvent.setEnabled(true);
                    Toast.makeText(UploadEventActivity.this, "Event uploaded successfully!", Toast.LENGTH_SHORT).show();
                    Log.d(TAG, "DocumentSnapshot added with ID: " + documentReference.getId());
                    finish(); // Go back to MapsActivity
                })
                .addOnFailureListener(e -> {
                    progressBarUpload.setVisibility(View.GONE);
                    buttonUploadEvent.setEnabled(true);
                    Toast.makeText(UploadEventActivity.this, "Error saving event: " + e.getMessage(), Toast.LENGTH_LONG).show();
                    Log.e(TAG, "Error adding document", e);
                });
    }
}
