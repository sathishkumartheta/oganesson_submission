package com.example.cityinsightmaps.models;

import java.util.List;

public class TrafficRouteData {
    private String api_provider;
    private String city;
    private List<RouteDetail> routes;
    private String timestamp; // Assuming this is a string like "YYYYMMDD_HHMMSS"

    public TrafficRouteData() {}
    // Getters and Setters for all fields
    public String getApi_provider() { return api_provider; }
    public void setApi_provider(String api_provider) { this.api_provider = api_provider; }
    public String getCity() { return city; }
    public void setCity(String city) { this.city = city; }
    public List<RouteDetail> getRoutes() { return routes; }
    public void setRoutes(List<RouteDetail> routes) { this.routes = routes; }
    public String getTimestamp() { return timestamp; }
    public void setTimestamp(String timestamp) { this.timestamp = timestamp; }
}
