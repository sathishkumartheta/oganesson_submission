package com.example.cityinsightmaps.models;

public class TemperatureData {
    private double actual;
    private double feels_like;
    private int humidity;

    public TemperatureData() {}

    // Getters and Setters
    public double getActual() { return actual; }
    public void setActual(double actual) { this.actual = actual; }
    public double getFeels_like() { return feels_like; }
    public void setFeels_like(double feels_like) { this.feels_like = feels_like; }
    public int getHumidity() { return humidity; }
    public void setHumidity(int humidity) { this.humidity = humidity; }
}
