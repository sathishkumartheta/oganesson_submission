package com.example.cityinsightmaps.models;
import com.google.firebase.firestore.ServerTimestamp;

import java.util.Date;
import java.util.List;
import java.util.Map;
public class CurrentUserResponseData {
    private AirQualityDetail air_quality;
    private List<TrafficRouteDetail> traffic;
    private WeatherDetail weather;
    @ServerTimestamp
    private Date timestamp; // Use Date for Firestore Timestamp type

    public CurrentUserResponseData() {
        // Default constructor required for Firestore
    }

    public AirQualityDetail getAir_quality() {
        return air_quality;
    }

    public void setAir_quality(AirQualityDetail air_quality) {
        this.air_quality = air_quality;
    }

    public List<TrafficRouteDetail> getTraffic() {
        return traffic;
    }

    public void setTraffic(List<TrafficRouteDetail> traffic) {
        this.traffic = traffic;
    }

    public WeatherDetail getWeather() {
        return weather;
    }

    public void setWeather(WeatherDetail weather) {
        this.weather = weather;
    }

    public Date getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(Date timestamp) {
        this.timestamp = timestamp;
    }

    // Nested class for Air Quality details
    public static class AirQualityDetail {
        private int aqi;
        private String aqi_category;
        private double co;
        private double no2;
        private double pm2_5;
        private String location; // Location as a string
        // Note: The timestamp here is part of the outer CurrentUserResponseData for the whole document

        public AirQualityDetail() {
            // Default constructor required for Firestore
        }

        public int getAqi() {
            return aqi;
        }

        public void setAqi(int aqi) {
            this.aqi = aqi;
        }

        public String getAqi_category() {
            return aqi_category;
        }

        public void setAqi_category(String aqi_category) {
            this.aqi_category = aqi_category;
        }

        public double getCo() {
            return co;
        }

        public void setCo(double co) {
            this.co = co;
        }

        public double getNo2() {
            return no2;
        }

        public void setNo2(double no2) {
            this.no2 = no2;
        }

        public double getPm2_5() {
            return pm2_5;
        }

        public void setPm2_5(double pm2_5) {
            this.pm2_5 = pm2_5;
        }

        public String getLocation() {
            return location;
        }

        public void setLocation(String location) {
            this.location = location;
        }
    }

    // Nested class for Traffic Route details (similar to existing RouteDetail but specific to this model)
    public static class TrafficRouteDetail {
        private double congestion_factor;
        private String destination;
        private int distance_meters;
        private int duration_seconds;
        private String source;
        private int static_duration_seconds;

        public TrafficRouteDetail() {
            // Default constructor required for Firestore
        }

        public double getCongestion_factor() {
            return congestion_factor;
        }

        public void setCongestion_factor(double congestion_factor) {
            this.congestion_factor = congestion_factor;
        }

        public String getDestination() {
            return destination;
        }

        public void setDestination(String destination) {
            this.destination = destination;
        }

        public int getDistance_meters() {
            return distance_meters;
        }

        public void setDistance_meters(int distance_meters) {
            this.distance_meters = distance_meters;
        }

        public int getDuration_seconds() {
            return duration_seconds;
        }

        public void setDuration_seconds(int duration_seconds) {
            this.duration_seconds = duration_seconds;
        }

        public String getSource() {
            return source;
        }

        public void setSource(String source) {
            this.source = source;
        }

        public int getStatic_duration_seconds() {
            return static_duration_seconds;
        }

        public void setStatic_duration_seconds(int static_duration_seconds) {
            this.static_duration_seconds = static_duration_seconds;
        }
    }

    // Nested class for Weather details
    public static class WeatherDetail {
        private String description;
        private double feels_like;
        private Double humidity; // Can be null
        private String location; // NEW: Added location field
        private double temperature;
        private double wind_speed;
        // Note: Location for weather is assumed to be the same as air_quality.location for plotting

        public WeatherDetail() {
            // Default constructor required for Firestore
        }

        public String getDescription() {
            return description;
        }

        public void setDescription(String description) {
            this.description = description;
        }

        public double getFeels_like() {
            return feels_like;
        }

        public void setFeels_like(double feels_like) {
            this.feels_like = feels_like;
        }

        public Double getHumidity() {
            return humidity;
        }

        public void setHumidity(Double humidity) {
            this.humidity = humidity;
        }

        // NEW: Getter and Setter for location
        public String getLocation() {
            return location;
        }

        public void setLocation(String location) {
            this.location = location;
        }

        public double getTemperature() {
            return temperature;
        }

        public void setTemperature(double temperature) {
            this.temperature = temperature;
        }

        public double getWind_speed() {
            return wind_speed;
        }

        public void setWind_speed(double wind_speed) {
            this.wind_speed = wind_speed;
        }
    }
}
