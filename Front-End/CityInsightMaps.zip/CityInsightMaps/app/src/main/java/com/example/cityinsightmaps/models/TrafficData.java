package com.example.cityinsightmaps.models;
import com.google.firebase.firestore.GeoPoint;
import java.util.Date;
public class TrafficData {
    private String id; // Document ID
    private GeoPoint location;
    private String description;
    private String severity; // e.g., "High", "Medium", "Low"
    private Date timestamp; // Unix timestamp

    public TrafficData() {} // Required for Firestore

    public TrafficData(String id, GeoPoint location, String description, String severity, Date timestamp) {
        this.id = id;
        this.location = location;
        this.description = description;
        this.severity = severity;
        this.timestamp = timestamp;
    }

    // Getters and Setters
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public GeoPoint getLocation() { return location; }
    public void setLocation(GeoPoint location) { this.location = location; }
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
    public String getSeverity() { return severity; }
    public void setSeverity(String severity) { this.severity = severity; }
    public Date getTimestamp() { return timestamp; }
    public void setTimestamp(Date timestamp) { this.timestamp = timestamp; }
}
