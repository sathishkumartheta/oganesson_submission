package com.example.cityinsightmaps.models;
import com.google.firebase.firestore.GeoPoint;

import java.util.Date;

public class AirQualityData {
    private String id;
    private GeoPoint location;
    private double aqi; // Air Quality Index
    private String pollutant; // e.g., "PM2.5", "O3"
    private Date timestamp;

    public AirQualityData() {}

    public AirQualityData(String id, GeoPoint location, double aqi, String pollutant, Date timestamp) {
        this.id = id;
        this.location = location;
        this.aqi = aqi;
        this.pollutant = pollutant;
        this.timestamp = timestamp;
    }

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public GeoPoint getLocation() { return location; }
    public void setLocation(GeoPoint location) { this.location = location; }
    public double getAqi() { return aqi; }
    public void setAqi(double aqi) { this.aqi = aqi; }
    public String getPollutant() { return pollutant; }
    public void setPollutant(String pollutant) { this.pollutant = pollutant; }
    public Date getTimestamp() { return timestamp; }
    public void setTimestamp(Date timestamp) { this.timestamp = timestamp; }

}
