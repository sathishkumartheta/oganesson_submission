package com.example.cityinsightmaps.models;
import com.google.firebase.firestore.GeoPoint;
import java.util.Date;
public class PowerCutData {

    private String id;
    private GeoPoint location;
    private String area;
    private String reason;
    private Date startTime;
    private Date estimatedEndTime;

    public PowerCutData() {}

    public PowerCutData(String id, GeoPoint location, String area, String reason, Date startTime, Date estimatedEndTime) {
        this.id = id;
        this.location = location;
        this.area = area;
        this.reason = reason;
        this.startTime = startTime;
        this.estimatedEndTime = estimatedEndTime;
    }

    // Getters and Setters
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public GeoPoint getLocation() { return location; }
    public void setLocation(GeoPoint location) { this.location = location; }
    public String getArea() { return area; }
    public void setArea(String area) { this.area = area; }
    public String getReason() { return reason; }
    public void setReason(String reason) { this.reason = reason; }
    public Date getStartTime() { return startTime; }
    public void setStartTime(Date startTime) { this.startTime = startTime; } // Corrected line
    public Date getEstimatedEndTime() { return estimatedEndTime; }
    public void setEstimatedEndTime(Date estimatedEndTime) { this.estimatedEndTime = estimatedEndTime; }
    }
