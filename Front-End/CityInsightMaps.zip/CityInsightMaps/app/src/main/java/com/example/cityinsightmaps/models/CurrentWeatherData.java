package com.example.cityinsightmaps.models;
import java.util.List;
import java.util.Map;
public class CurrentWeatherData {
    private String city;
    private List<LocationDetail> locations;

    public CurrentWeatherData() {}

    public String getCity() { return city; }
    public void setCity(String city) { this.city = city; }
    public List<LocationDetail> getLocations() { return locations; }
    public void setLocations(List<LocationDetail> locations) { this.locations = locations; }

    public static class LocationDetail {
        private double cloud_coverage;
        private double lat;
        private double lon;
        private String name;
        private String retrieval_status;
        private long sunrise;
        private long sunset;
        private TemperatureDetail temperature;
        private WeatherDetail weather;
        private WindDetail wind;

        public LocationDetail() {}

        public double getCloud_coverage() { return cloud_coverage; }
        public void setCloud_coverage(double cloud_coverage) { this.cloud_coverage = cloud_coverage; }
        public double getLat() { return lat; }
        public void setLat(double lat) { this.lat = lat; }
        public double getLon() { return lon; }
        public void setLon(double lon) { this.lon = lon; }
        public String getName() { return name; }
        public void setName(String name) { this.name = name; }
        public String getRetrieval_status() { return retrieval_status; }
        public void setRetrieval_status(String retrieval_status) { this.retrieval_status = retrieval_status; }
        public long getSunrise() { return sunrise; }
        public void setSunrise(long sunrise) { this.sunrise = sunrise; }
        public long getSunset() { return sunset; }
        public void setSunset(long sunset) { this.sunset = sunset; }
        public TemperatureDetail getTemperature() { return temperature; }
        public void setTemperature(TemperatureDetail temperature) { this.temperature = temperature; }
        public WeatherDetail getWeather() { return weather; }
        public void setWeather(WeatherDetail weather) { this.weather = weather; }
        public WindDetail getWind() { return wind; }
        public void setWind(WindDetail wind) { this.wind = wind; }
    }

    public static class TemperatureDetail {
        private double actual;
        private double feels_like;
        private int humidity;

        public TemperatureDetail() {}

        public double getActual() { return actual; }
        public void setActual(double actual) { this.actual = actual; }
        public double getFeels_like() { return feels_like; }
        public void setFeels_like(double feels_like) { this.feels_like = feels_like; }
        public int getHumidity() { return humidity; }
        public void setHumidity(int humidity) { this.humidity = humidity; }
    }

    public static class WeatherDetail {
        private String description;
        private String icon;
        private String main;

        public WeatherDetail() {}

        public String getDescription() { return description; }
        public void setDescription(String description) { this.description = description; }
        public String getIcon() { return icon; }
        public void setIcon(String icon) { this.icon = icon; }
        public String getMain() { return main; }
        public void setMain(String main) { this.main = main; }
    }

    public static class WindDetail {
        private double gust;
        private double speed;

        public WindDetail() {}

        public double getGust() { return gust; }
        public void setGust(double gust) { this.gust = gust; }
        public double getSpeed() { return speed; }
        public void setSpeed(double speed) { this.speed = speed; }
    }
}
