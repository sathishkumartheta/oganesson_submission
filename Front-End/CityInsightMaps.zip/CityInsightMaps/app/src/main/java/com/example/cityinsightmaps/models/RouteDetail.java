package com.example.cityinsightmaps.models;

public class RouteDetail {
    private double congestion_factor;
    private String destination;
    private int distance_meters;
    private int duration_seconds;
    private String source;
    private int static_duration_seconds;
    private String status;

    public RouteDetail() {}
    // Getters and Setters for all fields
    public double getCongestion_factor() { return congestion_factor; }
    public void setCongestion_factor(double congestion_factor) { this.congestion_factor = congestion_factor; }
    public String getDestination() { return destination; }
    public void setDestination(String destination) { this.destination = destination; }
    public int getDistance_meters() { return distance_meters; }
    public void setDistance_meters(int distance_meters) { this.distance_meters = distance_meters; }
    public int getDuration_seconds() { return duration_seconds; }
    public void setDuration_seconds(int duration_seconds) { this.duration_seconds = duration_seconds; }
    public String getSource() { return source; }
    public void setSource(String source) { this.source = source; }
    public int getStatic_duration_seconds() { return static_duration_seconds; }
    public void setStatic_duration_seconds(int static_duration_seconds) { this.static_duration_seconds = static_duration_seconds; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
}

