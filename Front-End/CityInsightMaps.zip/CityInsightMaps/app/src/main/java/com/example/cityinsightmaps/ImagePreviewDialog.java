package com.example.cityinsightmaps;
import static java.security.AccessController.getContext;

import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.DataSource;
import com.bumptech.glide.load.engine.GlideException;
import com.bumptech.glide.request.RequestListener;
import com.bumptech.glide.request.target.Target;

public class ImagePreviewDialog extends DialogFragment{
    private static final String ARG_IMAGE_URL = "imageUrl";
    private static final String ARG_DESCRIPTION = "description";
    public static ImagePreviewDialog newInstance(String imageUrl, String description) {
        ImagePreviewDialog fragment = new ImagePreviewDialog();
        Bundle args = new Bundle();
        args.putString(ARG_IMAGE_URL, imageUrl);
        args.putString(ARG_DESCRIPTION, description);
        fragment.setArguments(args);
        return fragment;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.dialog_image_preview, container, false);

        ImageView imageViewPopup = view.findViewById(R.id.imageViewPopup);
        ProgressBar progressBarImageLoad = view.findViewById(R.id.progressBarImageLoad);
        Button buttonCloseDialog = view.findViewById(R.id.buttonCloseDialog);
        TextView imageDescriptionTextView = view.findViewById(R.id.imageDescriptionTextView); // Initialize TextView

        if (getArguments() != null) {
            String imageUrl = getArguments().getString(ARG_IMAGE_URL);
            String description = getArguments().getString(ARG_DESCRIPTION); // Retrieve description
// Set the description text
            if (description != null && !description.isEmpty()) {
                imageDescriptionTextView.setText(description);
                imageDescriptionTextView.setVisibility(View.VISIBLE);
            } else {
                imageDescriptionTextView.setVisibility(View.GONE); // Hide if no description
            }
            if (imageUrl != null && !imageUrl.isEmpty()) {
                progressBarImageLoad.setVisibility(View.VISIBLE);
                Glide.with(this)
                        .load(imageUrl)
                        .listener(new RequestListener<Drawable>() {
                            @Override
                            public boolean onLoadFailed(@Nullable GlideException e, Object model, Target<Drawable> target, boolean isFirstResource) {
                                progressBarImageLoad.setVisibility(View.GONE);
                                Toast.makeText(getContext(), "Failed to load image.", Toast.LENGTH_SHORT).show();
                                return false; // Allow Glide to handle the error (e.g., show error drawable)
                            }

                            @Override
                            public boolean onResourceReady(Drawable resource, Object model, Target<Drawable> target, DataSource dataSource, boolean isFirstResource) {
                                progressBarImageLoad.setVisibility(View.GONE);
                                return false; // Allow Glide to display the image
                            }
                        })
                        .into(imageViewPopup);
            } else {
                imageViewPopup.setImageResource(android.R.drawable.ic_menu_gallery); // Placeholder
                Toast.makeText(getContext(), "No image URL provided.", Toast.LENGTH_SHORT).show();
            }
        }

        buttonCloseDialog.setOnClickListener(v -> dismiss()); // Close the dialog

        return view;
    }

    // Optional: Set dialog style if you want a full-screen or specific dialog behavior
    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Use STYLE_NO_TITLE to remove default dialog title bar
        // Use STYLE_NORMAL or STYLE_NO_FRAME for different appearances
        setStyle(DialogFragment.STYLE_NORMAL, android.R.style.Theme_DeviceDefault_Light_Dialog_NoActionBar_MinWidth);
    }
}
