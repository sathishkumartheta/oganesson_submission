package com.example.cityinsightmaps.models;
import java.util.List;
import java.util.Map;
public class CurrentAirQualityData {
    private String city;
    private List<LocationAQIDetail> locations;
    // Removed retrieval_status from here, as it's now in LocationAQIDetail
    private String source;
    private String timestamp;

    public CurrentAirQualityData() {
        // Default constructor required for Firestore
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public List<LocationAQIDetail> getLocations() {
        return locations;
    }

    public void setLocations(List<LocationAQIDetail> locations) {
        this.locations = locations;
    }

    // Removed getter/setter for retrieval_status from here

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public String getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(String timestamp) {
        this.timestamp = timestamp;
    }

    // Inner class for individual location's AQI details
    public static class LocationAQIDetail {
        private int aqi;
        private String aqi_category;
        private Map<String, Double> components; // This is already here
        private double lat;
        private double lon;
        private String name;
        private String retrieval_status; // MOVED HERE FROM OUTER CLASS

        public LocationAQIDetail() {
            // Default constructor required for Firestore
        }

        public int getAqi() {
            return aqi;
        }

        public void setAqi(int aqi) {
            this.aqi = aqi;
        }

        public String getAqi_category() {
            return aqi_category;
        }

        public void setAqi_category(String aqi_category) {
            this.aqi_category = aqi_category;
        }

        public Map<String, Double> getComponents() {
            return components;
        }

        public void setComponents(Map<String, Double> components) {
            this.components = components;
        }

        public double getLat() {
            return lat;
        }

        public void setLat(double lat) {
            this.lat = lat;
        }

        public double getLon() {
            return lon;
        }

        public void setLon(double lon) {
            this.lon = lon;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        // NEW GETTER AND SETTER FOR RETRIEVAL_STATUS IN INNER CLASS
        public String getRetrieval_status() {
            return retrieval_status;
        }

        public void setRetrieval_status(String retrieval_status) {
            this.retrieval_status = retrieval_status;
        }
    }
}
