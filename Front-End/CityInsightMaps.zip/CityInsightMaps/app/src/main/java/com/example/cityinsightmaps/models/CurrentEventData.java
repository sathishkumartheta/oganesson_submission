package com.example.cityinsightmaps.models;
import com.google.firebase.firestore.GeoPoint;

import java.util.Date;

public class CurrentEventData {
    private String description;
    private String event_type;
    private String location; // Stored as String, will need geocoding
    private String timestamp; // Stored as String

    public CurrentEventData() {}

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getEvent_type() {
        return event_type;
    }

    public void setEvent_type(String event_type) {
        this.event_type = event_type;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(String timestamp) {
        this.timestamp = timestamp;
    }
}
