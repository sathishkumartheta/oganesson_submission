package com.example.cityinsightmaps; // Ensure this matches your project's root package

import android.app.Application;
import android.util.Log;

import com.google.firebase.FirebaseApp;
import com.google.firebase.appcheck.FirebaseAppCheck;
import com.google.firebase.appcheck.debug.DebugAppCheckProviderFactory;
import com.google.firebase.appcheck.playintegrity.PlayIntegrityAppCheckProviderFactory;

public class MyApplication extends Application { // Renamed from MyApp to MyApplication

    private static final String TAG = "MyApplication"; // Updated TAG for consistency

    @Override
    public void onCreate() {
        super.onCreate();
        Log.d(TAG, "--------------------------------------------------");
        Log.d(TAG, "MyApplication onCreate called. Starting FirebaseApp and AppCheck initialization.");
        Log.d(TAG, "Application context: " + getApplicationContext().toString());

        try {
            // 1. Initialize FirebaseApp first
            FirebaseApp.initializeApp(this);
            Log.d(TAG, "FirebaseApp initialized successfully.");

            // 2. Get the FirebaseAppCheck instance
            FirebaseAppCheck firebaseAppCheck = FirebaseAppCheck.getInstance();
            Log.d(TAG, "FirebaseAppCheck instance obtained.");

            // 3. Install the appropriate App Check provider factory
            // Use BuildConfig.FIREBASE_APP_CHECK_DEBUG_TOKEN for conditional debug initialization
            if (BuildConfig.DEBUG && BuildConfig.FIREBASE_APP_CHECK_DEBUG_TOKEN != null && !BuildConfig.FIREBASE_APP_CHECK_DEBUG_TOKEN.isEmpty()) {
                Log.d(TAG, "Initializing App Check with DebugAppCheckProviderFactory.");
                firebaseAppCheck.installAppCheckProviderFactory(
                        DebugAppCheckProviderFactory.getInstance());
                Log.d(TAG, "DebugAppCheckProviderFactory installed for DEBUG build.");
                // The debug token itself will be logged by FirebaseAppCheck internally if DebugAppCheckProviderFactory is used.
                Log.d(TAG, "Check Logcat for 'Debug App Check token:' to register in Firebase Console.");
            } else {
                // For release builds, or if debug token is not configured/empty, use Play Integrity
                Log.d(TAG, "Initializing App Check with PlayIntegrityAppCheckProviderFactory.");
                firebaseAppCheck.installAppCheckProviderFactory(
                        PlayIntegrityAppCheckProviderFactory.getInstance());
                Log.d(TAG, "PlayIntegrityAppCheckProviderFactory installed for RELEASE build (or debug without token).");
            }
            Log.d(TAG, "Firebase App Check initialization attempt complete.");
        } catch (Exception e) {
            Log.e(TAG, "Error during Firebase/App Check initialization in MyApplication.onCreate(): " + e.getMessage(), e);
        }
        Log.d(TAG, "--------------------------------------------------");
    }
}