package com.example.cityinsightmaps.models;
import com.google.firebase.firestore.GeoPoint;

import java.util.Date;

public class WeatherData {
    private String id;
    private GeoPoint location;
    private double temperature; // in Celsius
    private String condition; // e.g., "Sunny", "Rainy"
    private double humidity; // percentage
    private Date timestamp;

    public WeatherData() {}

    public WeatherData(String id, GeoPoint location, double temperature, String condition, double humidity, Date timestamp) {
        this.id = id;
        this.location = location;
        this.temperature = temperature;
        this.condition = condition;
        this.humidity = humidity;
        this.timestamp = timestamp;
    }

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public GeoPoint getLocation() { return location; }
    public void setLocation(GeoPoint location) { this.location = location; }
    public double getTemperature() { return temperature; }
    public void setTemperature(double temperature) { this.temperature = temperature; }
    public String getCondition() { return condition; }
    public void setCondition(String condition) { this.condition = condition; }
    public double getHumidity() { return humidity; }
    public void setHumidity(double humidity) { this.humidity = humidity; }
    public Date getTimestamp() { return timestamp; }
    public void setTimestamp(Date timestamp) { this.timestamp = timestamp; }
}
