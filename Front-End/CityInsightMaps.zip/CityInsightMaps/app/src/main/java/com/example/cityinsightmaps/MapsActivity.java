package com.example.cityinsightmaps;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.Signature;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.location.Address;
import android.location.Geocoder;
import android.os.Bundle;
import android.util.Base64;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;


import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptor;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.PolylineOptions;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FieldValue;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.example.cityinsightmaps.models.*; // Import your data models
import com.example.cityinsightmaps.models.TrafficRouteData; // NEW: Import TrafficRouteData
import com.example.cityinsightmaps.models.RouteDetail; // NEW: Import RouteDetail
import com.google.android.material.tabs.TabLayout;
//import com.google.maps.android.PolylineEncoding; // NEW: Import for polyline decoding
import com.google.maps.android.PolyUtil;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import com.google.firebase.messaging.FirebaseMessaging; // NEW IMPORT

public class MapsActivity extends AppCompatActivity implements OnMapReadyCallback, GoogleMap.OnMarkerClickListener {
    private GoogleMap mMap;
    private FirebaseFirestore db;

    private FirebaseAuth mAuth;
    private TabLayout tabLayout;
    private EditText searchEditText;
    private ImageButton searchButton;
    private Button logoutButton; // New logout button
    // NEW UI elements for prompt input
    private EditText promptEditText;
    private Button submitPromptButton;
    private TextView realtimeCommentaryTextView;
    private FloatingActionButton fabUploadEvent; // New FAB for upload
    // No ViewPager2 needed if map is static and only markers change
    // private ViewPager2 viewPager; // If you want separate fragments for each tab
    // Lists to hold data
    private List<TrafficData> trafficDataList = new ArrayList<>();
    private List<AirQualityData> airQualityDataList = new ArrayList<>();
    private List<WeatherData> weatherDataList = new ArrayList<>();
    private List<CulturalPoliticalEvent> culturalPoliticalEventsList = new ArrayList<>();

    private List<CurrentUserData> currentuserdataList = new ArrayList<>();
    private List<PowerCutData> powerCutDataList = new ArrayList<>();
    private List<TrafficRouteData> trafficRouteDataList = new ArrayList<>(); // List for TrafficRouteData
    private List<CurrentWeatherData> currentWeatherDataList = new ArrayList<>(); // NEW: List for CurrentWeatherData
    private List<CurrentEventData> currentEventDataList = new ArrayList<>(); // NEW: List for CurrentEventData
    private List<CurrentAirQualityData> currentAirQualityDataList = new ArrayList<>();
    private List<CurrentUserResponseData> currentUserResponseDataList = new ArrayList<>(); // NEW LIST

    private List<CurrentMoodData> currentMoodDataList = new ArrayList<>(); // NEW LIST for Moodmap
    // Cache for geocoded locations to avoid repeated API calls
    private Map<String, LatLng> geocodedLocationsCache = new HashMap<>();
    private static final String TAG = "MapsActivity";
    // Executor for background tasks
    private ExecutorService executorService = Executors.newFixedThreadPool(2); // Use a small thread pool

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps); // This layout will be updated for tabs

        db = FirebaseFirestore.getInstance();
        mAuth = FirebaseAuth.getInstance();
        // Initialize map (from template)
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);

        // ... (UI setup for tabs and search box will go here)
        tabLayout = findViewById(R.id.tabLayout);
        searchEditText = findViewById(R.id.searchEditText);
        searchButton = findViewById(R.id.searchButton);
        realtimeCommentaryTextView = findViewById(R.id.realtimeCommentaryTextView); // Initialize the new TextView
        fabUploadEvent = findViewById(R.id.fabUploadEvent); // Initialize FAB
        logoutButton=findViewById(R.id.logoutButton);
        // NEW: Initialize prompt input UI elements
        promptEditText = findViewById(R.id.promptEditText);
        submitPromptButton = findViewById(R.id.submitPromptButton);
        setupTabs();
        setupSearch();
        fabUploadEvent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MapsActivity.this, UploadEventActivity.class);
                startActivity(intent);
            }
        });

        // Set up logout button click listener
        logoutButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                logoutUser();
            }
        });
// NEW: Set up listener for submit prompt button
        submitPromptButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String promptText = promptEditText.getText().toString().trim();

                if (promptText.isEmpty()) {
                    Toast.makeText(MapsActivity.this,
                            "Please enter some text for the prompt.",
                            Toast.LENGTH_SHORT).show();
                    return;
                }

                // Prepare data for Firestore
                Map<String, Object> promptData = new HashMap<>();
                promptData.put("prompt", promptText);
                promptData.put("timestamp", FieldValue.serverTimestamp()); // Add server timestamp

                // Add data to Firestore
                db.collection("current_user_prompt")
                        .add(promptData)
                        .addOnSuccessListener(documentReference -> {
                            Toast.makeText(MapsActivity.this,
                                    "Prompt submitted successfully!",
                                    Toast.LENGTH_SHORT).show();
                            promptEditText.setText(""); // Clear the textbox after submission
                            Log.d(TAG, "DocumentSnapshot added with ID: " + documentReference.getId());
                        })
                        .addOnFailureListener(e -> {
                            Toast.makeText(MapsActivity.this,
                                    "Error submitting prompt: " + e.getMessage(),
                                    Toast.LENGTH_LONG).show();
                            Log.w(TAG, "Error adding document", e);
                        });
            }
        });

        // Initial fetch for all data types
        fetchTrafficData();
        fetchAirQualityData();
        fetchWeatherData();
        fetchCulturalPoliticalEvents();

        fetchPowerCutData();
        fetchTrafficRouteData(); // Fetch traffic route data
        fetchCurrentWeatherData(); // NEW: Fetch current weather data
        fetchCurrentEventData(); // NEW: Fetch current event data
        fetchCurrentAirQualityData(); // NEW FETCH CALL
        fetchCurrentUserData();
        fetchCurrentUserResponseData(); // NEW FETCH CALL
        fetchCurrentMoodData(); // NEW FETCH CALL for Moodmap
        // Start listening for real-time commentary
        listenForRealtimeCommentary();

        logAppSignature();
        // NEW: Get and log the FCM registration token
        FirebaseMessaging.getInstance().getToken()
                .addOnCompleteListener(task -> {
                    if (!task.isSuccessful()) {
                        Log.w(TAG, "Fetching FCM registration token failed", task.getException());
                        return;
                    }
                    // Get new FCM registration token
                    String token = task.getResult();
                    Log.d(TAG, "FCM Registration Token: " + token);
                    // You would typically send this token to your backend server
                    // or subscribe to a topic here.
                    // Example: FirebaseMessaging.getInstance().subscribeToTopic("commentary_updates");
                });
    }
    // NEW METHOD: To log the app's package name and SHA-1 fingerprint
    private void logAppSignature() {
        try {
            PackageInfo info = getPackageManager().getPackageInfo(
                    getPackageName(),
                    PackageManager.GET_SIGNATURES);
            for (Signature signature : info.signatures) {
                MessageDigest md = MessageDigest.getInstance("SHA");
                md.update(signature.toByteArray());
                // Convert byte array to hexadecimal string
                StringBuilder hexString = new StringBuilder();
                for (byte b : md.digest()) {
                    hexString.append(String.format("%02X:", b));
                }
                String sha1Hex = hexString.toString();
                if (sha1Hex.length() > 0) {
                    sha1Hex = sha1Hex.substring(0, sha1Hex.length() - 1); // Remove trailing colon
                }

                Log.d(TAG, "App Package Name: " + getPackageName());
                Log.d(TAG, "App SHA-1 Fingerprint (HEX): " + sha1Hex);
            }
        } catch (PackageManager.NameNotFoundException e) {
            Log.e(TAG, "Package not found: " + e.getMessage());
        } catch (NoSuchAlgorithmException e) {
            Log.e(TAG, "SHA algorithm not found: " + e.getMessage());
        }
    }
    protected void onDestroy() {
        super.onDestroy();
        executorService.shutdownNow(); // Shut down the executor when activity is destroyed
    }
    // New method to listen for real-time commentary
    private void listenForRealtimeCommentary() {
        // Listen to a specific document for real-time updates
     /*   db.collection("commentary").document("live_feed")
                .addSnapshotListener((documentSnapshot, e) -> {
                    if (e != null) {
                        Log.w(TAG, "Listen for commentary failed.", e);
                        realtimeCommentaryTextView.setText("Error loading commentary.");
                        return;
                    }

                    if (documentSnapshot != null && documentSnapshot.exists()) {
                        String commentaryText = documentSnapshot.getString("text");
                        if (commentaryText != null) {
                            realtimeCommentaryTextView.setText(commentaryText);
                            Log.d(TAG, "Real-time commentary updated: " + commentaryText);
                        } else {
                            realtimeCommentaryTextView.setText("No commentary available.");
                            Log.d(TAG, "Commentary document exists but 'text' field is null.");
                        }
                    } else {
                        realtimeCommentaryTextView.setText("No live commentary feed found.");
                        Log.d(TAG, "Live commentary document does not exist.");
                    }
                });*/
        db.collection("current_pred_data").document("latest")
                .addSnapshotListener((documentSnapshot, e) -> {
                    if (e != null) {
                        Log.w(TAG, "Listen for commentary failed.", e);
                        realtimeCommentaryTextView.setText("Error loading commentary.");
                        return;
                    }

                    if (documentSnapshot != null && documentSnapshot.exists()) {
                        // Access the 'data' map first, then get the 'commentary' string from it
                        Map<String, Object> dataMap = (Map<String, Object>) documentSnapshot.get("data");
                        String commentaryText = null;
                        if (dataMap != null) {
                            commentaryText = (String) dataMap.get("commentary");
                        }

                        if (commentaryText != null) {
                            realtimeCommentaryTextView.setText(commentaryText);
                            Log.d(TAG, "Real-time commentary updated: " + commentaryText);
                        } else {
                            realtimeCommentaryTextView.setText("No commentary available.");
                            Log.d(TAG, "Commentary document exists but 'commentary' field is null or 'data' map is missing.");
                        }
                    } else {
                        realtimeCommentaryTextView.setText("No live commentary feed found.");
                        Log.d(TAG, "Live commentary document does not exist.");
                    }
                });
    }


    private void setupTabs() {
       // String[] tabTitles = {"Traffic Routes","Current Weather", "Current Events","Current Air Quality","Current User Data", "Power Cuts","Traffic","Air Quality", "Weather", "Events"};
        String[] tabTitles = {"Home","Traffic Routes","Current Weather", "Current Events","Current Air Quality","Current User Data", "Moodmap"};

        for (String title : tabTitles) {
            tabLayout.addTab(tabLayout.newTab().setText(title));
        }

        tabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                currentActiveTab = tab.getText().toString();
                updateMapMarkers(currentActiveTab);
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {
                // Not needed for this implementation, as map.clear() handles it
            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {
                // Optional: Re-center map or refresh data
            }
        });

        // Select the default tab initially
        tabLayout.selectTab(tabLayout.getTabAt(0));
    }
    private void setupSearch() {
        searchButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                performLocationSearch();
            }
        });

        searchEditText.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                if (actionId == EditorInfo.IME_ACTION_SEARCH ||
                        (event != null && event.getKeyCode() == KeyEvent.KEYCODE_ENTER && event.getAction() == KeyEvent.ACTION_DOWN)) {
                    performLocationSearch();
                    return true;
                }
                return false;
            }
        });
    }

    private void performLocationSearch() {
        String locationName = searchEditText.getText().toString().trim();
        if (locationName.isEmpty()) {
            Toast.makeText(this, "Please enter a location to search.", Toast.LENGTH_SHORT).show();
            return;
        }

        // Hide keyboard
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        imm.hideSoftInputFromWindow(searchEditText.getWindowToken(), 0);

        Geocoder geocoder = new Geocoder(this, Locale.getDefault());
        try {
            List<Address> addresses = geocoder.getFromLocationName(locationName, 1);
            if (addresses != null && !addresses.isEmpty()) {
                Address address = addresses.get(0);
                LatLng searchLocation = new LatLng(address.getLatitude(), address.getLongitude());
                mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(searchLocation, 14)); // Zoom to 14
                mMap.addMarker(new MarkerOptions().position(searchLocation).title(address.getAddressLine(0)));
            } else {
                Toast.makeText(this, "Location not found.", Toast.LENGTH_SHORT).show();
            }
        } catch (IOException e) {
            Log.e(TAG, "Geocoding failed: " + e.getMessage());
            Toast.makeText(this, "Error searching location: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }
    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

        // Example: Move camera to a default location (e.g., your city)
        LatLng defaultLocation = new LatLng(12.9716, 77.5946); // Example: bengaluru coordinates
        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(defaultLocation, 10));

        // Set marker click listener
        mMap.setOnMarkerClickListener(this); // Set the listener here

        // NEW: Set custom info window adapter
        mMap.setInfoWindowAdapter(new CustomInfoWindowAdapter(this));
        // Initial update of markers based on the default tab
        updateMapMarkers(currentActiveTab);
        // Request location permissions if needed for current location
        // checkLocationPermission(); // Implement this method if you want current location

        // Start fetching data
        fetchTrafficData();
        fetchAirQualityData();
        fetchWeatherData();
        fetchCulturalPoliticalEvents();
        fetchCurrentEventData(); // NEW: Fetch current event data
        fetchCurrentUserData();
        fetchPowerCutData();

    }

    // NEW: Fetch data for the "Home" tab from current_user_response
    private void fetchCurrentUserResponseData() {
        db.collection("current_user_response")
                .orderBy("timestamp", Query.Direction.DESCENDING) // Order by timestamp to get the latest
                .limit(1) // Get only the latest document
                .addSnapshotListener((snapshots, e) -> {
                    if (e != null) {
                        Log.w(TAG, "Listen failed for current_user_response.", e);
                        return;
                    }
                    currentUserResponseDataList.clear();
                    if (snapshots != null && !snapshots.isEmpty()) {
                        // There should only be one document due to limit(1)
                        for (QueryDocumentSnapshot doc : snapshots) {
                            CurrentUserResponseData data = doc.toObject(CurrentUserResponseData.class);
                            currentUserResponseDataList.add(data);
                            Log.d(TAG, "Current User Response data fetched. Timestamp: " + data.getTimestamp());
                            break; // Take only the first (latest) document
                        }
                        if (currentActiveTab.equals("Home")) {
                            updateMapMarkers("Home");
                        }
                    } else {
                        Log.d(TAG, "Current user response document does not exist or is empty.");
                    }
                });
    }

    private void fetchTrafficData() {
        db.collection("traffic_data1")
                .addSnapshotListener((snapshots, e) -> { // Use addSnapshotListener for real-time updates
                    if (e != null) {
                        Log.w(TAG, "Listen failed.", e);
                        return;
                    }
                    trafficDataList.clear();
                    if (snapshots != null) {
                        for (QueryDocumentSnapshot doc : snapshots) {
                            TrafficData data = doc.toObject(TrafficData.class);
                            data.setId(doc.getId()); // Set document ID
                            trafficDataList.add(data);
                        }
                        Log.d(TAG, "Traffic data fetched: " + trafficDataList.size());
                        // Update map if this tab is active
                        if (currentActiveTab.equals("Traffic")) { // Assuming a variable currentActiveTab
                            updateMapMarkers("Traffic");
                        }
                    }
                    else{
                        Log.d(TAG, "Traffic data not fetched: " + trafficDataList.size());
                    }
                });
    }

    private void fetchAirQualityData() {
        db.collection("air_quality_data")
                .addSnapshotListener((snapshots, e) -> {
                    if (e != null) { Log.w(TAG, "Listen failed.", e); return; }
                    airQualityDataList.clear();
                    if (snapshots != null) {
                        for (QueryDocumentSnapshot doc : snapshots) {
                            AirQualityData data = doc.toObject(AirQualityData.class);
                            data.setId(doc.getId());
                            airQualityDataList.add(data);
                        }
                        Log.d(TAG, "Air Quality data fetched: " + airQualityDataList.size());
                        if (currentActiveTab.equals("Air Quality")) {
                            updateMapMarkers("Air Quality");
                        }
                    }
                });
    }

    private void fetchWeatherData() {
        db.collection("weather_data1")
                .addSnapshotListener((snapshots, e) -> {
                    if (e != null) { Log.w(TAG, "Listen failed.", e); return; }
                    weatherDataList.clear();
                    if (snapshots != null) {
                        for (QueryDocumentSnapshot doc : snapshots) {
                            WeatherData data = doc.toObject(WeatherData.class);
                            data.setId(doc.getId());
                            weatherDataList.add(data);
                        }
                        Log.d(TAG, "Weather data fetched: " + weatherDataList.size());
                        if (currentActiveTab.equals("Weather")) {
                            updateMapMarkers("Weather");
                        }
                    }
                });
    }

    private void fetchCulturalPoliticalEvents() {
        db.collection("cultural_political_events")
                .addSnapshotListener((snapshots, e) -> {
                    if (e != null) { Log.w(TAG, "Listen failed.", e); return; }
                    culturalPoliticalEventsList.clear();
                    if (snapshots != null) {
                        for (QueryDocumentSnapshot doc : snapshots) {
                            CulturalPoliticalEvent data = doc.toObject(CulturalPoliticalEvent.class);
                            data.setId(doc.getId());
                            culturalPoliticalEventsList.add(data);
                        }
                        Log.d(TAG, "Cultural/Political Events data fetched: " + culturalPoliticalEventsList.size());
                        if (currentActiveTab.equals("Events")) {
                            updateMapMarkers("Events");
                        }
                    }
                });
    }
    private void fetchCurrentUserData() {
        db.collection("current_user_data")
                .addSnapshotListener((snapshots, e) -> {
                    if (e != null) { Log.w(TAG, "Listen failed.", e); return; }
                    currentuserdataList.clear();
                    if (snapshots != null) {
                        for (QueryDocumentSnapshot doc : snapshots) {
                            CurrentUserData data = doc.toObject(CurrentUserData.class);
                            data.setId(doc.getId());
                            currentuserdataList.add(data);
                        }
                        Log.d(TAG, "User data fetched: " + currentuserdataList.size());
                        if (currentActiveTab.equals("Current User Data")) {
                            updateMapMarkers("Current User Data");
                        }
                    }
                });
    }

    private void fetchPowerCutData() {
        db.collection("power_cut_data")
                .addSnapshotListener((snapshots, e) -> {
                    if (e != null) { Log.w(TAG, "Listen failed.", e); return; }
                    powerCutDataList.clear();
                    if (snapshots != null) {
                        for (QueryDocumentSnapshot doc : snapshots) {
                            PowerCutData data = doc.toObject(PowerCutData.class);
                            data.setId(doc.getId());
                            powerCutDataList.add(data);
                        }
                        Log.d(TAG, "Power Cut data fetched: " + powerCutDataList.size());
                        if (currentActiveTab.equals("Power Cuts")) {
                            updateMapMarkers("Power Cuts");
                        }
                    }
                });
    }
    // Method to fetch traffic route data
    private void fetchTrafficRouteData() {
        db.collection("current_traffic_data")
                .document("latest") // Assuming a single document for latest routes
                .addSnapshotListener((documentSnapshot, e) -> {
                    if (e != null) {
                        Log.w(TAG, "Listen for traffic routes failed.", e);
                        return;
                    }
                    trafficRouteDataList.clear(); // Clear previous route data
                    if (documentSnapshot != null && documentSnapshot.exists()) {
                        TrafficRouteData data = documentSnapshot.toObject(TrafficRouteData.class);
                        if (data != null) {
                            trafficRouteDataList.add(data); // Add the single document
                            Log.d(TAG, "Traffic Route data fetched for " + data.getCity() + ". Routes: " + data.getRoutes().size());
                            // UPDATED: Update map if "Traffic Routes" tab is active
                            if (currentActiveTab.equals("Traffic Routes")) {
                                updateMapMarkers("Traffic Routes");
                            }
                        }
                    } else {
                        Log.d(TAG, "Traffic routes document does not exist.");
                    }
                });
    }
    // NEW: Method to fetch current weather data
    private void fetchCurrentWeatherData() {
        db.collection("current_weather_data")
                .document("bengaluru_latest_weather") // Assuming a single document for latest weather
                .addSnapshotListener((documentSnapshot, e) -> {
                    if (e != null) {
                        Log.w(TAG, "Listen for current weather failed.", e);
                        return;
                    }
                    currentWeatherDataList.clear(); // Clear previous data
                    if (documentSnapshot != null && documentSnapshot.exists()) {
                        CurrentWeatherData data = documentSnapshot.toObject(CurrentWeatherData.class);
                        if (data != null) {
                            currentWeatherDataList.add(data); // Add the single document
                            Log.d(TAG, "Current Weather data fetched for " + data.getCity() + ". Locations: " + data.getLocations().size());
                            if (currentActiveTab.equals("Current Weather")) {
                                updateMapMarkers("Current Weather");
                            }
                        }
                    } else {
                        Log.d(TAG, "Current weather document does not exist.");
                    }
                });
    }

    private void fetchCurrentAirQualityData() {
        db.collection("current_airquality_data")
                .document("bengaluru_latest_aqi")
                .addSnapshotListener((documentSnapshot, e) -> {
                    if (e != null) {
                        Log.w(TAG, "Listen for current air quality failed.", e);
                        return;
                    }
                    currentAirQualityDataList.clear();
                    if (documentSnapshot != null && documentSnapshot.exists()) {
                        CurrentAirQualityData data = documentSnapshot.toObject(CurrentAirQualityData.class);
                        if (data != null) {
                            currentAirQualityDataList.add(data);
                            Log.d(TAG, "Current Air Quality data fetched for " + data.getCity() + ". Locations: " + data.getLocations().size());
                            if (currentActiveTab.equals("Current Air Quality")) {
                                updateMapMarkers("Current Air Quality");
                            }
                        }
                    } else {
                        Log.d(TAG, "Current air quality document does not exist.");
                    }
                });
    }

    // NEW: Method to fetch current event data
    private void fetchCurrentEventData() {
        db.collection("current_events_data")
                .addSnapshotListener((snapshots, e) -> {
                    if (e != null) {
                        Log.w(TAG, "Listen for current events failed.", e);
                        return;
                    }
                    currentEventDataList.clear();
                    if (snapshots != null) {
                        for (QueryDocumentSnapshot doc : snapshots) {
                            CurrentEventData data = doc.toObject(CurrentEventData.class);
                            currentEventDataList.add(data);
                        }
                        Log.d(TAG, "Current Event data fetched: " + currentEventDataList.size());
                        if (currentActiveTab.equals("Current Events")) {
                            updateMapMarkers("Current Events");
                        }
                    }
                });
    }

    // NEW: Fetch data for the "Moodmap" tab from current_mood_data
    private void fetchCurrentMoodData() {
        db.collection("current_mood_data")
                .addSnapshotListener((snapshots, e) -> {
                    if (e != null) {
                        Log.w(TAG, "Listen failed for current_mood_data.", e);
                        return;
                    }
                    currentMoodDataList.clear();
                    if (snapshots != null) {
                        for (QueryDocumentSnapshot doc : snapshots) {
                            CurrentMoodData data = doc.toObject(CurrentMoodData.class);
                            currentMoodDataList.add(data);
                        }
                        Log.d(TAG, "Current Mood data fetched: " + currentMoodDataList.size());
                        if (currentActiveTab.equals("Moodmap")) {
                            updateMapMarkers("Moodmap");
                        }
                    }
                });
    }
    // This method will be called when a tab is selected
    private void updateMapMarkers(String dataType) {
        if (mMap == null) return;

        mMap.clear(); // Clear existing markers

        switch (dataType) {
            case "Home": // NEW CASE for Home tab
                if (!currentUserResponseDataList.isEmpty()) {
                    CurrentUserResponseData homeData = currentUserResponseDataList.get(0);
                    // Using fixed small offsets to prevent direct overlaps for main home tab markers
                    double baseOffsetLat = 0.0001; // Approx 11 meters latitude
                    double baseOffsetLon = 0.0001; // Approx 11 meters longitude

                    // Plot Air Quality
                    if (homeData.getAir_quality() != null) {
                        String aqLocationName = homeData.getWeather().getLocation();
                        Log.d(TAG, "Air Quality Location: " + homeData.getAir_quality().getLocation());
                        if (aqLocationName != null && !aqLocationName.trim().isEmpty()) {
                            LatLng originalAqLatLng = getLatLngFromAddress(aqLocationName);
                            LatLng finalAqLatLng;
                            if (originalAqLatLng != null) {
                                // Apply a specific offset for Air Quality: slightly North
                                finalAqLatLng = new LatLng(originalAqLatLng.latitude + baseOffsetLat, originalAqLatLng.longitude);
                            } else {
                                Log.w(TAG, "Could not geocode Air Quality location: " + aqLocationName + ". Falling back to default location.");
                                // Fallback to a central location if geocoding fails for AQ
                                LatLng fallbackLatLng = new LatLng(12.9716, 77.5946); // Bengaluru coordinates
                                finalAqLatLng = new LatLng(fallbackLatLng.latitude + baseOffsetLat, fallbackLatLng.longitude);
                            }

                            Marker marker = mMap.addMarker(new MarkerOptions()
                                    .position(finalAqLatLng)
                                    .icon(getBitmapDescriptorFromVector(this, R.drawable.ic_air_quality))
                                    .title("Air Quality: " + aqLocationName));
                            if (marker != null) {
                                marker.setTag(homeData.getAir_quality()); // Set tag for info window
                            }
                        } else {
                            Log.w(TAG, "Air Quality location name is null or empty. Skipping plotting.");
                        }
                    }

                    // Plot Weather (now uses its own location field)
                    if (homeData.getWeather() != null) {
                        String weatherLocationName = homeData.getWeather().getLocation(); // Use weather's own location
                        // Fallback if weather location is null/empty
                        if (weatherLocationName == null || weatherLocationName.trim().isEmpty()) {
                            if (homeData.getAir_quality() != null &&
                                    homeData.getAir_quality().getLocation() != null &&
                                    !homeData.getAir_quality().getLocation().trim().isEmpty()) {
                                weatherLocationName = homeData.getAir_quality().getLocation();
                            } else {
                                weatherLocationName = "Bengaluru"; // Final fallback
                            }
                        }

                        if (weatherLocationName != null && !weatherLocationName.trim().isEmpty()) {
                            LatLng originalWeatherLatLng = getLatLngFromAddress(weatherLocationName);
                            LatLng finalWeatherLatLng;
                            if (originalWeatherLatLng != null) {
                                // Apply a specific offset for Weather: slightly South
                                finalWeatherLatLng = new LatLng(originalWeatherLatLng.latitude - baseOffsetLat, originalWeatherLatLng.longitude);
                            } else {
                                Log.w(TAG, "Could not geocode Weather location: " + weatherLocationName + ". Falling back to default location.");
                                LatLng fallbackLatLng = new LatLng(12.9716, 77.5946); // Bengaluru coordinates
                                finalWeatherLatLng = new LatLng(fallbackLatLng.latitude - baseOffsetLat, fallbackLatLng.longitude);
                            }

                            Marker marker = mMap.addMarker(new MarkerOptions()
                                    .position(finalWeatherLatLng)
                                    .icon(getBitmapDescriptorFromVector(this, R.drawable.ic_weather))
                                    .title("Weather: " + weatherLocationName));
                            if (marker != null) {
                                marker.setTag(homeData.getWeather()); // Set tag for info window
                            }
                        } else {
                            Log.w(TAG, "Weather location name is null or empty after fallbacks. Skipping plotting.");
                        }
                    }

                    // Plot Traffic Routes
                    if (homeData.getTraffic() != null && !homeData.getTraffic().isEmpty()) {
                        for (CurrentUserResponseData.TrafficRouteDetail route : homeData.getTraffic()) {
                            // Ensure source and destination are not null/empty before geocoding
                            if (route.getSource() != null && !route.getSource().trim().isEmpty() &&
                                    route.getDestination() != null && !route.getDestination().trim().isEmpty()) {

                                LatLng originalSourceLatLng = getLatLngFromAddress(route.getSource());
                                LatLng originalDestinationLatLng = getLatLngFromAddress(route.getDestination());

                                LatLng finalSourceLatLng = originalSourceLatLng;
                                if (originalSourceLatLng != null) {
                                    // Apply a specific offset for Traffic Source: slightly East
                                    finalSourceLatLng = new LatLng(originalSourceLatLng.latitude, originalSourceLatLng.longitude + baseOffsetLon);
                                } else {
                                    Log.w(TAG, "Could not geocode Traffic Source location: " + route.getSource() + ". Falling back to default location.");
                                    LatLng fallbackLatLng = new LatLng(12.9716, 77.5946); // Bengaluru coordinates
                                    finalSourceLatLng = new LatLng(fallbackLatLng.latitude, fallbackLatLng.longitude + baseOffsetLon);
                                }

                                LatLng finalDestinationLatLng = originalDestinationLatLng;
                                if (originalDestinationLatLng != null) {
                                    // Apply a specific offset for Traffic Destination: slightly West
                                    finalDestinationLatLng = new LatLng(originalDestinationLatLng.latitude, originalDestinationLatLng.longitude - baseOffsetLon);
                                } else {
                                    Log.w(TAG, "Could not geocode Traffic Destination location: " + route.getDestination() + ". Falling back to default location.");
                                    LatLng fallbackLatLng = new LatLng(12.9716, 77.5946); // Bengaluru coordinates
                                    finalDestinationLatLng = new LatLng(fallbackLatLng.latitude, fallbackLatLng.longitude - baseOffsetLon);
                                }

                                if (finalSourceLatLng != null && finalDestinationLatLng != null) {
                                    int polylineColor;
                                    if (route.getCongestion_factor() >= 1.5) {
                                        polylineColor = ContextCompat.getColor(this, R.color.traffic_high_congestion);
                                    } else if (route.getCongestion_factor() >= 1.2) {
                                        polylineColor = ContextCompat.getColor(this, R.color.traffic_medium_congestion);
                                    } else {
                                        polylineColor = ContextCompat.getColor(this, R.color.traffic_low_congestion);
                                    }
                                    // Call the specific overloaded method for CurrentUserResponseData.TrafficRouteDetail
                                    fetchDirectionsAndDrawRoute(finalSourceLatLng, finalDestinationLatLng, polylineColor, route);
                                } else {
                                    Log.w(TAG, "Could not geocode location for Home tab route: " + route.getSource() + " to " + route.getDestination() + ". Skipping plotting.");
                                }
                            } else {
                                Log.w(TAG, "Home tab route source or destination is null/empty. Skipping plotting.");
                            }
                        }
                    }
                }
                break;

            case "Traffic":
                for (TrafficData data : trafficDataList) {
                    if (data.getLocation() != null) {
                        LatLng latLng = new LatLng(data.getLocation().getLatitude(), data.getLocation().getLongitude());
                        mMap.addMarker(new MarkerOptions()
                                .position(latLng)
                                .title("Traffic: " + data.getDescription())
                                .snippet("Severity: " + data.getSeverity())
                                .icon(getBitmapDescriptorFromVector(this, R.drawable.ic_traffic))); // Custom icon
                    }
                }
                break;
            case "Traffic Routes": // NEW CASE for Traffic Routes tab
                if (!trafficRouteDataList.isEmpty()) {
                    TrafficRouteData currentRoutes = trafficRouteDataList.get(0); // Assuming one document for routes
                    for (RouteDetail route : currentRoutes.getRoutes()) {
                        LatLng sourceLatLng = getLatLngFromAddress(route.getSource() + ", " + currentRoutes.getCity());
                        LatLng destinationLatLng = getLatLngFromAddress(route.getDestination() + ", " + currentRoutes.getCity());

                        if (sourceLatLng != null && destinationLatLng != null) {
                            // Determine polyline color based on congestion factor
                            int polylineColor;
                            if (route.getCongestion_factor() >= 1.5) {
                                polylineColor = ContextCompat.getColor(this, R.color.traffic_high_congestion); // Red
                            } else if (route.getCongestion_factor() >= 1.2) {
                                polylineColor = ContextCompat.getColor(this, R.color.traffic_medium_congestion); // Orange
                            } else {
                                polylineColor = ContextCompat.getColor(this, R.color.traffic_low_congestion); // blue
                            }
                            // NEW: Fetch directions and draw the actual road route
                            fetchDirectionsAndDrawRoute(sourceLatLng, destinationLatLng, polylineColor, route);

/*
                            mMap.addPolyline(new PolylineOptions()
                                    .add(sourceLatLng, destinationLatLng)
                                    .width(10) // Width of the polyline
                                    .color(polylineColor)
                                    .geodesic(true) // Follows the curvature of the earth
                                    .jointType(com.google.android.gms.maps.model.JointType.ROUND) // Smooth joints
                                    .startCap(new com.google.android.gms.maps.model.RoundCap()) // Rounded start
                                    .endCap(new com.google.android.gms.maps.model.RoundCap())); // Rounded end

                            // Optionally add markers for source and destination of routes
                            mMap.addMarker(new MarkerOptions()
                                    .position(sourceLatLng)
                                    .title("Source: " + route.getSource())
                                    .snippet(String.format(Locale.getDefault(), "Congestion: %.2f, Duration: %d sec", route.getCongestion_factor(), route.getDuration_seconds()))
                                    .icon(getBitmapDescriptorFromVector(this, R.drawable.ic_traffic_route_start))); // Custom icon for route start

                            mMap.addMarker(new MarkerOptions()
                                    .position(destinationLatLng)
                                    .title("Destination: " + route.getDestination())
                                    .snippet(String.format(Locale.getDefault(), "Congestion: %.2f, Duration: %d sec", route.getCongestion_factor(), route.getDuration_seconds()))
                                    .icon(getBitmapDescriptorFromVector(this, R.drawable.ic_traffic_route_end))); // Custom icon for route end
                       */
                        } else {
                            Log.w(TAG, "Could not geocode location for route: " + route.getSource() + " to " + route.getDestination());
                        }
                    }
                }
                break;
            case "Historical Weather": // UPDATED: Case for "Historical Weather" tab
                for (WeatherData data : weatherDataList) {
                    if (data.getLocation() != null) {
                        LatLng latLng = new LatLng(data.getLocation().getLatitude(), data.getLocation().getLongitude());
                        mMap.addMarker(new MarkerOptions()
                                .position(latLng)
                                .title("Weather: " + data.getCondition())
                                .snippet(String.format(Locale.getDefault(), "Temp: %.1f°C, Humidity: %.0f%%", data.getTemperature(), data.getHumidity()))
                                .icon(getBitmapDescriptorFromVector(this, R.drawable.ic_weather)));
                    }
                }
                break;
            case "Current Weather":
                if (!currentWeatherDataList.isEmpty()) {
                    CurrentWeatherData currentWeatherData = currentWeatherDataList.get(0);
                    for (CurrentWeatherData.LocationDetail locDetail : currentWeatherData.getLocations()) {
                        LatLng latLng = new LatLng(locDetail.getLat(), locDetail.getLon());
                        Marker marker = mMap.addMarker(new MarkerOptions()
                                .position(latLng)
                                .icon(getBitmapDescriptorFromVector(this, R.drawable.ic_weather)));
                        if (marker != null) {
                            marker.setTag(locDetail); // Set the LocationDetail object as tag
                        }
                    }
                }
                break;
            case "Current Events": // NEW: Case for "Current Events" tab
                for (CurrentEventData data : currentEventDataList) {
                    // Use data.getLocation() directly, assuming it contains the city name or a geocodable string
                    LatLng eventLatLng = getLatLngFromAddress(data.getLocation());
                    if (eventLatLng != null) {
                        String title = "Event: " + data.getEvent_type();
                        String snippet = data.getDescription() + "\nTime: " + data.getTimestamp();
                        mMap.addMarker(new MarkerOptions()
                                .position(eventLatLng)
                                .title(title)
                                .snippet(snippet)
                                .icon(getBitmapDescriptorFromVector(this, R.drawable.ic_event))); // Using existing event icon
                    } else {
                        Log.w(TAG, "Could not geocode location for current event: " + data.getLocation());
                    }
                }
                break;
            case "Current Air Quality": // NEW CASE
                if (!currentAirQualityDataList.isEmpty()) {
                    CurrentAirQualityData currentAirQuality = currentAirQualityDataList.get(0);
                    for (CurrentAirQualityData.LocationAQIDetail locDetail : currentAirQuality.getLocations()) {
                        LatLng latLng = new LatLng(locDetail.getLat(), locDetail.getLon());
                        Marker marker = mMap.addMarker(new MarkerOptions()
                                .position(latLng)
                                .icon(getBitmapDescriptorFromVector(this, R.drawable.ic_air_quality))); // Reusing existing air quality icon
                        if (marker != null) {
                            marker.setTag(locDetail);
                        }
                    }
                }
                break;
            case "Air Quality":
                for (AirQualityData data : airQualityDataList) {
                    if (data.getLocation() != null) {
                        LatLng latLng = new LatLng(data.getLocation().getLatitude(), data.getLocation().getLongitude());
                        mMap.addMarker(new MarkerOptions()
                                .position(latLng)
                                .title("Air Quality: AQI " + data.getAqi())
                                .snippet("Pollutant: " + data.getPollutant())
                                .icon(getBitmapDescriptorFromVector(this, R.drawable.ic_air_quality)));
                    }
                }
                break;
            case "Weather":
                for (WeatherData data : weatherDataList) {
                    if (data.getLocation() != null) {
                        LatLng latLng = new LatLng(data.getLocation().getLatitude(), data.getLocation().getLongitude());
                        mMap.addMarker(new MarkerOptions()
                                .position(latLng)
                                .title("Weather: " + data.getCondition())
                                .snippet(String.format(Locale.getDefault(), "Temp: %.1f°C, Humidity: %.0f%%", data.getTemperature(), data.getHumidity()))
                                .icon(getBitmapDescriptorFromVector(this, R.drawable.ic_weather)));
                    }
                }
                break;

            case "Current User Data":
               /* for (CulturalPoliticalEvent data : culturalPoliticalEventsList) {
                    if (data.getLocation() != null) {
                        LatLng latLng = new LatLng(data.getLocation().getLatitude(), data.getLocation().getLongitude());
                        mMap.addMarker(new MarkerOptions()
                                .position(latLng)
                                .title("Event: " + data.getName())
                                .snippet("Type: " + data.getType() + ", " + data.getDescription())
                                .icon(getBitmapDescriptorFromVector(this, R.drawable.ic_event)));
                    }
                }
                break;*/
                for (CurrentUserData data : currentuserdataList) {
                    if (data.getLocation() != null) {
                        LatLng latLng = new LatLng(data.getLocation().getLatitude(), data.getLocation().getLongitude());
                        MarkerOptions markerOptions = new MarkerOptions()
                                .position(latLng)
                                .title("Event: " + data.getName())
                                .snippet("Type: " + data.getType() + ", " + data.getDescription());

                        // If it's a user-reported event with an image, you might want a different icon
                        if ("UserReported".equals(data.getType()) && data.getImageUrl() != null && !data.getImageUrl().isEmpty()) {
                            markerOptions.icon(getBitmapDescriptorFromVector(this, R.drawable.ic_user_event_image)); // NEW: Custom icon for user-reported events with images
                        } else {
                            markerOptions.icon(getBitmapDescriptorFromVector(this, R.drawable.ic_event));
                        }
                        // Set the CulturalPoliticalEvent object as the marker's tag
                        // This allows us to retrieve it later when the marker is clicked
                        Marker marker = mMap.addMarker(markerOptions);
                        if (marker != null) {
                            marker.setTag(data); // Store the entire object as a tag
                        }
                    }
                }
                break;
            case "Events":
               /* for (CulturalPoliticalEvent data : culturalPoliticalEventsList) {
                    if (data.getLocation() != null) {
                        LatLng latLng = new LatLng(data.getLocation().getLatitude(), data.getLocation().getLongitude());
                        mMap.addMarker(new MarkerOptions()
                                .position(latLng)
                                .title("Event: " + data.getName())
                                .snippet("Type: " + data.getType() + ", " + data.getDescription())
                                .icon(getBitmapDescriptorFromVector(this, R.drawable.ic_event)));
                    }
                }
                break;*/
            for (CulturalPoliticalEvent data : culturalPoliticalEventsList) {
                if (data.getLocation() != null) {
                    LatLng latLng = new LatLng(data.getLocation().getLatitude(), data.getLocation().getLongitude());
                    MarkerOptions markerOptions = new MarkerOptions()
                            .position(latLng)
                            .title("Event: " + data.getName())
                            .snippet("Type: " + data.getType() + ", " + data.getDescription());

                    // If it's a user-reported event with an image, you might want a different icon
                    if ("UserReported".equals(data.getType()) && data.getImageUrl() != null && !data.getImageUrl().isEmpty()) {
                        markerOptions.icon(getBitmapDescriptorFromVector(this, R.drawable.ic_user_event_image)); // NEW: Custom icon for user-reported events with images
                    } else {
                        markerOptions.icon(getBitmapDescriptorFromVector(this, R.drawable.ic_event));
                    }
                    // Set the CulturalPoliticalEvent object as the marker's tag
                    // This allows us to retrieve it later when the marker is clicked
                    Marker marker = mMap.addMarker(markerOptions);
                    if (marker != null) {
                        marker.setTag(data); // Store the entire object as a tag
                    }
                }
            }
            break;


            case "Power Cuts":
                for (PowerCutData data : powerCutDataList) {
                    if (data.getLocation() != null) {
                        LatLng latLng = new LatLng(data.getLocation().getLatitude(), data.getLocation().getLongitude());
                        mMap.addMarker(new MarkerOptions()
                                .position(latLng)
                                .title("Power Cut: " + data.getArea())
                                .snippet("Reason: " + data.getReason() +
                                        ", Est. End: " + (data.getEstimatedEndTime() != null ?
                                        new java.text.SimpleDateFormat("MMM dd, yyyy hh:mm a", Locale.getDefault()).format(data.getEstimatedEndTime()) : "N/A"))
                                .icon(getBitmapDescriptorFromVector(this, R.drawable.ic_power_cut)));
                    }
                }
                break;
            case "Moodmap": // NEW CASE for Moodmap tab
                if (!currentMoodDataList.isEmpty()) {
                    for (CurrentMoodData data : currentMoodDataList) {
                        String localityName = data.getLocality();
                        if (localityName != null && !localityName.trim().isEmpty()) {
                            LatLng latLng = getLatLngFromAddress(localityName);
                            if (latLng != null) {
                                int moodIconResId;
                                // Determine smiley icon based on mood_number
                                if (data.getMood_number() >= 8) {
                                    moodIconResId = R.drawable.ic_mood_good;
                                } else if (data.getMood_number() >= 4) {
                                    moodIconResId = R.drawable.ic_mood_neutral;
                                } else {
                                    moodIconResId = R.drawable.ic_mood_bad;
                                }

                                Marker marker = mMap.addMarker(new MarkerOptions()
                                        .position(latLng)
                                        .icon(getBitmapDescriptorFromVector(this, moodIconResId))
                                        .title("Mood: " + data.getMood())
                                        .snippet("Locality: " + data.getLocality() + "\nReason: " + data.getReason()));
                                if (marker != null) {
                                    marker.setTag(data); // Set tag for info window
                                }
                            } else {
                                Log.w(TAG, "Could not geocode Moodmap location: " + localityName + ". Skipping plotting.");
                            }
                        } else {
                            Log.w(TAG, "Moodmap locality name is null or empty. Skipping plotting.");
                        }
                    }
                }
                break;
            default:
                // Show all or nothing
                break;
        }
    }


    // Helper method to geocode an address string to LatLng
    private LatLng getLatLngFromAddress(String addressString) {
        // Check cache first
        if (geocodedLocationsCache.containsKey(addressString)) {
            return geocodedLocationsCache.get(addressString);
        }

        Geocoder geocoder = new Geocoder(this, Locale.getDefault());
        try {
            List<Address> addresses = geocoder.getFromLocationName(addressString, 1);
            if (addresses != null && !addresses.isEmpty()) {
                Address address = addresses.get(0);
                LatLng latLng = new LatLng(address.getLatitude(), address.getLongitude());
                geocodedLocationsCache.put(addressString, latLng); // Add to cache
                return latLng;
            }
        } catch (IOException e) {
            Log.e(TAG, "Geocoding failed for address: " + addressString + " - " + e.getMessage());
        }
        return null; // Return null if geocoding fails
    }
    // Helper method to convert vector drawable to BitmapDescriptor for markers
    // Create vector assets: Right-click on 'res/drawable' -> New -> Vector Asset
    private BitmapDescriptor getBitmapDescriptorFromVector(Context context, int vectorResId) {
        Drawable vectorDrawable = ContextCompat.getDrawable(context, vectorResId);
        if (vectorDrawable == null) {
            return BitmapDescriptorFactory.defaultMarker();
        }
        vectorDrawable.setBounds(0, 0, 100, 100);
     //   vectorDrawable.setBounds(0, 0, vectorDrawable.getIntrinsicWidth(), vectorDrawable.getIntrinsicHeight());

       // Bitmap bitmap = Bitmap.createBitmap(vectorDrawable.getIntrinsicWidth(),
         //       vectorDrawable.getIntrinsicHeight(), Bitmap.Config.ARGB_8888);
        Bitmap bitmap = Bitmap.createBitmap(100,
                100, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        vectorDrawable.draw(canvas);
        return BitmapDescriptorFactory.fromBitmap(bitmap);
    }
    @Override
    public boolean onMarkerClick(@NonNull Marker marker) {
        // Check if the clicked marker has a CulturalPoliticalEvent object as its tag
        Object tag = marker.getTag();
        if (tag instanceof CulturalPoliticalEvent) {
            CulturalPoliticalEvent event = (CulturalPoliticalEvent) tag;
            String imageUrl = event.getImageUrl();
            String videoUrl = event.getVideoUrl();
            String description= event.getDescription();
            if (imageUrl != null && !imageUrl.isEmpty()) {
                // Show image popup
                ImagePreviewDialog.newInstance(imageUrl,description).show(getSupportFragmentManager(), "image_preview_dialog");
                return true; // Consume the event
            } else if (videoUrl != null && !videoUrl.isEmpty()) {
                // For video, you might launch a video player or show a video thumbnail.
                // For simplicity, we'll just show a toast for now.
                Toast.makeText(this, "Video associated with this event: " + videoUrl, Toast.LENGTH_LONG).show();
                // If you want to play video, you'd launch an Intent or a custom video player dialog
                // Intent videoIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(videoUrl));
                // startActivity(videoIntent);
                return true; // Consume the event
            }
        }
        // Return false to indicate that we have not consumed the event and that
        // the default behavior (displaying info window) should occur.
        return false;
    }
    // New method to handle user logout
    private void logoutUser() {
        mAuth.signOut(); // Sign out the current user from Firebase Authentication
        Toast.makeText(this, "Logged out successfully.", Toast.LENGTH_SHORT).show();
        // Redirect to LoginActivity
        Intent intent = new Intent(MapsActivity.this, LoginActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK); // Clear back stack
        startActivity(intent);
        finish(); // Finish MapsActivity
    }

    // Overloaded method to draw routes specifically for CurrentUserResponseData.TrafficRouteDetail
    private void fetchDirectionsAndDrawRoute(LatLng origin, LatLng destination, int polylineColor,
                                             CurrentUserResponseData.TrafficRouteDetail routeDetail) {
        executorService.execute(() -> {
            HttpURLConnection urlConnection = null;
            BufferedReader reader = null;
            try {
                String apiKey = getString(R.string.google_maps_api_key);

                Log.d(TAG, "API Key Used by App: " + apiKey);

                String urlString = "https://maps.googleapis.com/maps/api/directions/json?" +
                        "origin=" + URLEncoder.encode(origin.latitude + "," + origin.longitude, "UTF-8") +
                        "&destination=" + URLEncoder.encode(destination.latitude + "," + destination.longitude, "UTF-8") +
                        "&mode=driving" +
                        "&key=" + apiKey;

                Log.d(TAG, "Directions API URL: " + urlString);

                URL url = new URL(urlString);
                urlConnection = (HttpURLConnection) url.openConnection();
                urlConnection.setRequestMethod("GET");
                urlConnection.connect();

                int responseCode = urlConnection.getResponseCode();
                if (responseCode == HttpURLConnection.HTTP_OK) {
                    reader = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
                    StringBuilder buffer = new StringBuilder();
                    String line;
                    while ((line = reader.readLine()) != null) {
                        buffer.append(line);
                    }
                    String jsonResponse = buffer.toString();

                    JSONObject jsonObject = new JSONObject(jsonResponse);

                    Log.d(TAG, "Directions API Response: " + jsonResponse);

                    JSONArray routes = jsonObject.getJSONArray("routes");
                    if (routes.length() > 0) {
                        JSONObject route = routes.getJSONObject(0);
                        JSONObject overviewPolyline = route.getJSONObject("overview_polyline");
                        String encodedPolyline = overviewPolyline.getString("points");

                        List<LatLng> decodedPath = PolyUtil.decode(encodedPolyline);

                        runOnUiThread(() -> {
                            if (mMap != null) {
                                mMap.addPolyline(new PolylineOptions()
                                        .addAll(decodedPath)
                                        .width(10)
                                        .color(polylineColor)
                                        .geodesic(true)
                                        .jointType(com.google.android.gms.maps.model.JointType.ROUND)
                                        .startCap(new com.google.android.gms.maps.model.RoundCap())
                                        .endCap(new com.google.android.gms.maps.model.RoundCap()));

                                Marker sourceMarker = mMap.addMarker(new MarkerOptions()
                                        .position(origin)
                                        .icon(getBitmapDescriptorFromVector(MapsActivity.this, R.drawable.ic_traffic_route_start)));
                                if (sourceMarker != null) {
                                    sourceMarker.setTag(routeDetail); // Set tag to the specific route detail
                                }

                                Marker destMarker = mMap.addMarker(new MarkerOptions()
                                        .position(destination)
                                        .icon(getBitmapDescriptorFromVector(MapsActivity.this, R.drawable.ic_traffic_route_end)));
                                if (destMarker != null) {
                                    destMarker.setTag(routeDetail); // Set tag to the specific route detail
                                }
                            }
                        });
                    } else {
                        Log.w(TAG, "No routes found for " + routeDetail.getSource() + " to " + routeDetail.getDestination());
                        runOnUiThread(() -> Toast.makeText(MapsActivity.this, "No route found for " + routeDetail.getSource() + " to " + routeDetail.getDestination(), Toast.LENGTH_SHORT).show());
                    }
                } else {
                    Log.e(TAG, "Directions API request failed with code: " + responseCode);
                    runOnUiThread(() -> Toast.makeText(MapsActivity.this, "Failed to get directions: " + responseCode, Toast.LENGTH_SHORT).show());
                }

            } catch (Exception e) {
                Log.e(TAG, "Error fetching directions: " + e.getMessage(), e);
                runOnUiThread(() -> Toast.makeText(MapsActivity.this, "Error fetching directions: " + e.getMessage(), Toast.LENGTH_LONG).show());
            } finally {
                if (urlConnection != null) {
                    urlConnection.disconnect();
                }
                if (reader != null) {
                    try {
                        reader.close();
                    } catch (IOException e) {
                        Log.e(TAG, "Error closing reader", e);
                    }
                }
            }
        });
    }

    // Original fetchDirectionsAndDrawRoute for TrafficRouteData.RouteDetail
    private void fetchDirectionsAndDrawRoute(LatLng origin, LatLng destination, int polylineColor, RouteDetail routeDetail) {
        executorService.execute(() -> {
            HttpURLConnection urlConnection = null;
            BufferedReader reader = null;
            try {
                String apiKey = getString(R.string.google_maps_api_key);

                Log.d(TAG, "API Key Used by App: " + apiKey);

                String urlString = "https://maps.googleapis.com/maps/api/directions/json?" +
                        "origin=" + URLEncoder.encode(origin.latitude + "," + origin.longitude, "UTF-8") +
                        "&destination=" + URLEncoder.encode(destination.latitude + "," + destination.longitude, "UTF-8") +
                        "&mode=driving" +
                        "&key=" + apiKey;

                Log.d(TAG, "Directions API URL: " + urlString);

                URL url = new URL(urlString);
                urlConnection = (HttpURLConnection) url.openConnection();
                urlConnection.setRequestMethod("GET");
                urlConnection.connect();

                int responseCode = urlConnection.getResponseCode();
                if (responseCode == HttpURLConnection.HTTP_OK) {
                    reader = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
                    StringBuilder buffer = new StringBuilder();
                    String line;
                    while ((line = reader.readLine()) != null) {
                        buffer.append(line);
                    }
                    String jsonResponse = buffer.toString();

                    JSONObject jsonObject = new JSONObject(jsonResponse);

                    Log.d(TAG, "Directions API Response: " + jsonResponse);

                    JSONArray routes = jsonObject.getJSONArray("routes");
                    if (routes.length() > 0) {
                        JSONObject route = routes.getJSONObject(0);
                        JSONObject overviewPolyline = route.getJSONObject("overview_polyline");
                        String encodedPolyline = overviewPolyline.getString("points");

                        List<LatLng> decodedPath = PolyUtil.decode(encodedPolyline);

                        runOnUiThread(() -> {
                            if (mMap != null) {
                                mMap.addPolyline(new PolylineOptions()
                                        .addAll(decodedPath)
                                        .width(10)
                                        .color(polylineColor)
                                        .geodesic(true)
                                        .jointType(com.google.android.gms.maps.model.JointType.ROUND)
                                        .startCap(new com.google.android.gms.maps.model.RoundCap())
                                        .endCap(new com.google.android.gms.maps.model.RoundCap()));

                                Marker sourceMarker = mMap.addMarker(new MarkerOptions()
                                        .position(origin)
                                        .icon(getBitmapDescriptorFromVector(MapsActivity.this, R.drawable.ic_traffic_route_start)));
                                if (sourceMarker != null) {
                                    sourceMarker.setTag(routeDetail);
                                }

                                Marker destMarker = mMap.addMarker(new MarkerOptions()
                                        .position(destination)
                                        .icon(getBitmapDescriptorFromVector(MapsActivity.this, R.drawable.ic_traffic_route_end)));
                                if (destMarker != null) {
                                    destMarker.setTag(routeDetail);
                                }
                            }
                        });
                    } else {
                        Log.w(TAG, "No routes found for " + routeDetail.getSource() + " to " + routeDetail.getDestination());
                        runOnUiThread(() -> Toast.makeText(MapsActivity.this, "No route found for " + routeDetail.getSource() + " to " + routeDetail.getDestination(), Toast.LENGTH_SHORT).show());
                    }
                } else {
                    Log.e(TAG, "Directions API request failed with code: " + responseCode);
                    runOnUiThread(() -> Toast.makeText(MapsActivity.this, "Failed to get directions: " + responseCode, Toast.LENGTH_SHORT).show());
                }

            } catch (Exception e) {
                Log.e(TAG, "Error fetching directions: " + e.getMessage(), e);
                runOnUiThread(() -> Toast.makeText(MapsActivity.this, "Error fetching directions: " + e.getMessage(), Toast.LENGTH_LONG).show());
            } finally {
                if (urlConnection != null) {
                    urlConnection.disconnect();
                }
                if (reader != null) {
                    try {
                        reader.close();
                    } catch (IOException e) {
                        Log.e(TAG, "Error closing reader", e);
                    }
                }
            }
        });
    }

    /*
    // NEW: Method to fetch directions and draw route
    private void fetchDirectionsAndDrawRoute(LatLng origin, LatLng destination, int polylineColor, RouteDetail routeDetail) {
        executorService.execute(() -> {
            HttpURLConnection urlConnection = null;
            BufferedReader reader = null;

            try {
                String apiKey = getString(R.string.google_maps_api_key);
                
                String urlString = "https://maps.googleapis.com/maps/api/directions/json?" +
                        "origin=" + URLEncoder.encode(origin.latitude + "," + origin.longitude, "UTF-8") +
                        "&destination=" + URLEncoder.encode(destination.latitude + "," + destination.longitude, "UTF-8") +
                        "&mode=driving" +
                        "&key=" + apiKey;
// NEW: Log the full URL for debugging
                Log.d(TAG, "Directions API URL: " + urlString);

                URL url = new URL(urlString);
                urlConnection = (HttpURLConnection) url.openConnection();
                urlConnection.setRequestMethod("GET");
                urlConnection.connect();

                int responseCode = urlConnection.getResponseCode();
                if (responseCode == HttpURLConnection.HTTP_OK) {
                    reader = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
                    StringBuilder buffer = new StringBuilder();
                    String line;
                    while ((line = reader.readLine()) != null) {
                        buffer.append(line);
                    }
                    String jsonResponse = buffer.toString();

                    JSONObject jsonObject = new JSONObject(jsonResponse);
                    JSONArray routes = jsonObject.getJSONArray("routes");
                    if (routes.length() > 0) {
                        JSONObject route = routes.getJSONObject(0);
                        JSONObject overviewPolyline = route.getJSONObject("overview_polyline");
                        String encodedPolyline = overviewPolyline.getString("points");

                        List<LatLng> decodedPath = PolyUtil.decode(encodedPolyline);

                        runOnUiThread(() -> {
                            if (mMap != null) {
                                mMap.addPolyline(new PolylineOptions()
                                        .addAll(decodedPath)
                                        .width(10)
                                        .color(polylineColor)
                                        .geodesic(true)
                                        .jointType(com.google.android.gms.maps.model.JointType.ROUND)
                                        .startCap(new com.google.android.gms.maps.model.RoundCap())
                                        .endCap(new com.google.android.gms.maps.model.RoundCap()));

                                Marker sourceMarker = mMap.addMarker(new MarkerOptions()
                                        .position(origin)
                                        // Use MapsActivity.this for context here
                                        .icon(getBitmapDescriptorFromVector(MapsActivity.this, R.drawable.ic_traffic_route_start)));
                                if (sourceMarker != null) {
                                    sourceMarker.setTag(routeDetail);
                                }

                                Marker destMarker = mMap.addMarker(new MarkerOptions()
                                        .position(destination)
                                        // Use MapsActivity.this for context here
                                        .icon(getBitmapDescriptorFromVector(MapsActivity.this, R.drawable.ic_traffic_route_end)));
                                if (destMarker != null) {
                                    destMarker.setTag(routeDetail);
                                }
                            }
                        });
                    } else {
                        Log.w(TAG, "No routes found for " + routeDetail.getSource() + " to " + routeDetail.getDestination());
                        // Use MapsActivity.this for context here
                        runOnUiThread(() -> Toast.makeText(MapsActivity.this, "No route found for " + routeDetail.getSource() + " to " + routeDetail.getDestination(), Toast.LENGTH_SHORT).show());
                    }
                } else {
                    Log.e(TAG, "Directions API request failed with code: " + responseCode);
                    // Use MapsActivity.this for context here
                    runOnUiThread(() -> Toast.makeText(MapsActivity.this, "Failed to get directions: " + responseCode, Toast.LENGTH_SHORT).show());
                }

            } catch (Exception e) {
                Log.e(TAG, "Error fetching directions: " + e.getMessage(), e);
                // Use MapsActivity.this for context here
                runOnUiThread(() -> Toast.makeText(MapsActivity.this, "Error fetching directions: " + e.getMessage(), Toast.LENGTH_LONG).show());
            } finally {
                if (urlConnection != null) {
                    urlConnection.disconnect();
                }
                if (reader != null) {
                    try {
                        reader.close();
                    } catch (IOException e) {
                        Log.e(TAG, "Error closing reader", e);
                    }
                }
            }
        });
    }
*/
    // NEW: Custom Info Window Adapter
    private class CustomInfoWindowAdapter implements GoogleMap.InfoWindowAdapter {

        private final View mWindow;
        private final Context mContext;

        CustomInfoWindowAdapter(Context context) {
            mContext = context;
            mWindow = LayoutInflater.from(context).inflate(R.layout.custom_info_window, null);
        }

        @Override
        public View getInfoWindow(@NonNull Marker marker) {
            // This method is called first. If it returns null, getInfoContents is called.
            // If it returns a view, that view is used as the info window.
            // We'll return the fully inflated view from getInfoContents for full customization.
            return null; // Returning null here means getInfoContents will be called
        }

        @Override
        public View getInfoContents(@NonNull Marker marker) {
            render(marker, mWindow);
            return mWindow;
        }

        private void render(Marker marker, View view) {
            TextView titleUi = view.findViewById(R.id.info_window_title);
            TextView snippetUi = view.findViewById(R.id.info_window_snippet);
            TextView detailsUi = view.findViewById(R.id.info_window_details);

            // Clear previous content
            titleUi.setText("");
            snippetUi.setText("");
            detailsUi.setText("");

            // Set Title (from marker title)
            String title = marker.getTitle();
            if (title != null) {
                titleUi.setText(title);
            }

            // Set Snippet (from marker snippet)
            String snippet = marker.getSnippet();
            if (snippet != null) {
                snippetUi.setText(snippet);
            }

            // Dynamically build details based on the marker's tag (data object)
            Object tag = marker.getTag();
            StringBuilder detailsBuilder = new StringBuilder();

            if (tag instanceof TrafficData) {
                TrafficData data = (TrafficData) tag;
                detailsBuilder.append("Description: ").append(data.getDescription()).append("\n");
                detailsBuilder.append("Severity: ").append(data.getSeverity()).append("\n");
                detailsBuilder.append("Timestamp: ").append(new java.util.Date(String.valueOf(data.getTimestamp())).toLocaleString());
            } else if (tag instanceof AirQualityData) {
                AirQualityData data = (AirQualityData) tag;
                detailsBuilder.append("AQI: ").append(data.getAqi()).append("\n");
                detailsBuilder.append("Pollutant: ").append(data.getPollutant()).append("\n");
                detailsBuilder.append("Timestamp: ").append(new java.util.Date(String.valueOf(data.getTimestamp())).toLocaleString());
            } else if (tag instanceof WeatherData) {
                WeatherData data = (WeatherData) tag;
                detailsBuilder.append("Condition: ").append(data.getCondition()).append("\n");
                detailsBuilder.append(String.format(Locale.getDefault(), "Temp: %.1f°C, Humidity: %.0f%%\n", data.getTemperature(), data.getHumidity()));
                detailsBuilder.append("Timestamp: ").append(new java.util.Date(String.valueOf(data.getTimestamp())).toLocaleString());
            } else if (tag instanceof CurrentWeatherData.LocationDetail) { // Specific for CurrentWeatherData's nested LocationDetail
                CurrentWeatherData.LocationDetail data = (CurrentWeatherData.LocationDetail) tag;
                detailsBuilder.append("Location: ").append(data.getName()).append("\n");
                detailsBuilder.append(String.format(Locale.getDefault(), "Actual Temp: %.1f°C (Feels like: %.1f°C)\n", data.getTemperature().getActual(), data.getTemperature().getFeels_like()));
                detailsBuilder.append(String.format(Locale.getDefault(), "Humidity: %d%%\n", data.getTemperature().getHumidity()));
                detailsBuilder.append("Description: ").append(data.getWeather().getDescription()).append("\n");
                detailsBuilder.append(String.format(Locale.getDefault(), "Wind Speed: %.2f m/s (Gust: %.2f m/s)\n", data.getWind().getSpeed(), data.getWind().getGust()));
                detailsBuilder.append("Cloud Coverage: ").append(data.getCloud_coverage()).append("%\n");
                detailsBuilder.append("Sunrise: ").append(new java.util.Date(data.getSunrise() * 1000).toLocaleString()).append("\n"); // Convert Unix timestamp to milliseconds
                detailsBuilder.append("Sunset: ").append(new java.util.Date(data.getSunset() * 1000).toLocaleString()); // Convert Unix timestamp to milliseconds
            } else if (tag instanceof CurrentEventData) { // Specific for CurrentEventData
                CurrentEventData data = (CurrentEventData) tag;
                detailsBuilder.append("Description: ").append(data.getDescription()).append("\n");
                detailsBuilder.append("Event Type: ").append(data.getEvent_type()).append("\n");
                detailsBuilder.append("Location: ").append(data.getLocation()).append("\n");
                detailsBuilder.append("Timestamp: ").append(data.getTimestamp());
            }else if (tag instanceof CurrentAirQualityData.LocationAQIDetail) {
                CurrentAirQualityData.LocationAQIDetail data = (CurrentAirQualityData.LocationAQIDetail) tag;
                detailsBuilder.append("Location: ").append(data.getName()).append("\n");
                detailsBuilder.append("AQI: ").append(data.getAqi()).append("\n");
                detailsBuilder.append("Category: ").append(data.getAqi_category()).append("\n");
                detailsBuilder.append("Components:\n");
                if (data.getComponents() != null) {
                    for (Map.Entry<String, Double> entry : data.getComponents().entrySet()) {
                        detailsBuilder.append(String.format(Locale.getDefault(), "  %s: %.2f\n", entry.getKey().toUpperCase(), entry.getValue()));
                    }
                }
            } else if (tag instanceof PowerCutData) {
                PowerCutData data = (PowerCutData) tag;
                detailsBuilder.append("Area: ").append(data.getArea()).append("\n");
                detailsBuilder.append("Reason: ").append(data.getReason()).append("\n");
                detailsBuilder.append("Start Time: ").append(new java.util.Date(String.valueOf(data.getStartTime())).toLocaleString()).append("\n");
                detailsBuilder.append("Estimated End Time: ").append(new java.util.Date(String.valueOf(data.getEstimatedEndTime())).toLocaleString());
            } else if (tag instanceof RouteDetail) { // Specific for Traffic Routes
                RouteDetail data = (RouteDetail) tag;
                detailsBuilder.append("Source: ").append(data.getSource()).append("\n");
                detailsBuilder.append("Destination: ").append(data.getDestination()).append("\n");
                detailsBuilder.append(String.format(Locale.getDefault(), "Congestion Factor: %.2f\n", data.getCongestion_factor()));
                detailsBuilder.append(String.format(Locale.getDefault(), "Distance: %d meters\n", data.getDistance_meters()));
                detailsBuilder.append(String.format(Locale.getDefault(), "Current Duration: %d seconds\n", data.getDuration_seconds()));
                detailsBuilder.append(String.format(Locale.getDefault(), "Static Duration: %d seconds\n", data.getStatic_duration_seconds()));
                detailsBuilder.append("Status: ").append(data.getStatus());
            } // NEW: Handle CurrentUserResponseData for Home tab
            else if (tag instanceof CurrentUserResponseData.AirQualityDetail) {
                CurrentUserResponseData.AirQualityDetail data = (CurrentUserResponseData.AirQualityDetail) tag;
                detailsBuilder.append("Location: ").append(data.getLocation()).append("\n");
                detailsBuilder.append("AQI: ").append(data.getAqi()).append("\n");
                detailsBuilder.append("Category: ").append(data.getAqi_category()).append("\n");
                detailsBuilder.append(String.format(Locale.getDefault(), "CO: %.2f\n", data.getCo()));
                detailsBuilder.append(String.format(Locale.getDefault(), "NO2: %.2f\n", data.getNo2()));
                detailsBuilder.append(String.format(Locale.getDefault(), "PM2.5: %.2f\n", data.getPm2_5()));
            } else if (tag instanceof CurrentUserResponseData.WeatherDetail) {
                CurrentUserResponseData.WeatherDetail data = (CurrentUserResponseData.WeatherDetail) tag;
                detailsBuilder.append("Location: ").append(data.getLocation()).append("\n"); // Display weather location
                detailsBuilder.append("Condition: ").append(data.getDescription()).append("\n");
                detailsBuilder.append(String.format(Locale.getDefault(), "Temp: %.1f°C (Feels like: %.1f°C)\n", data.getTemperature(), data.getFeels_like()));
                if (data.getHumidity() != null) {
                    detailsBuilder.append(String.format(Locale.getDefault(), "Humidity: %.0f%%\n", data.getHumidity()));
                }
                detailsBuilder.append(String.format(Locale.getDefault(), "Wind Speed: %.2f m/s\n", data.getWind_speed()));
            } else if (tag instanceof CurrentUserResponseData.TrafficRouteDetail) { // Specific for Home tab routes
                CurrentUserResponseData.TrafficRouteDetail data = (CurrentUserResponseData.TrafficRouteDetail) tag;
                detailsBuilder.append("Source: ").append(data.getSource()).append("\n");
                detailsBuilder.append("Destination: ").append(data.getDestination()).append("\n");
                detailsBuilder.append(String.format(Locale.getDefault(), "Congestion Factor: %.2f\n", data.getCongestion_factor()));
                detailsBuilder.append(String.format(Locale.getDefault(), "Distance: %d meters\n", data.getDistance_meters()));
                detailsBuilder.append(String.format(Locale.getDefault(), "Current Duration: %d seconds\n", data.getDuration_seconds()));
                detailsBuilder.append(String.format(Locale.getDefault(), "Static Duration: %d seconds\n", data.getStatic_duration_seconds()));
            }else if (tag instanceof CurrentMoodData) { // NEW: Handle CurrentMoodData for Moodmap tab
                CurrentMoodData data = (CurrentMoodData) tag;
                detailsBuilder.append("Locality: ").append(data.getLocality()).append("\n");
                detailsBuilder.append("Mood: ").append(data.getMood()).append("\n");
                detailsBuilder.append("Mood Number: ").append(data.getMood_number()).append("\n");
                detailsBuilder.append("Reason: ").append(data.getReason());
            }

            detailsUi.setText(detailsBuilder.toString());
        }
    }
    // Placeholder for current active tab. This will be managed by TabLayout/ViewPager.
    private String currentActiveTab = "Traffic Routes"; // Default tab
}
