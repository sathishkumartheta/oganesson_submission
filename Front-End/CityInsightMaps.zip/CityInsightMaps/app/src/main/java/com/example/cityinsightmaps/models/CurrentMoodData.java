package com.example.cityinsightmaps.models;

public class CurrentMoodData {
    private String locality;
    private String mood;
    private int mood_number;
    private String reason;

    public CurrentMoodData() {
        // Default constructor required for Firestore
    }

    public String getLocality() {
        return locality;
    }

    public void setLocality(String locality) {
        this.locality = locality;
    }

    public String getMood() {
        return mood;
    }

    public void setMood(String mood) {
        this.mood = mood;
    }

    public int getMood_number() {
        return mood_number;
    }

    public void setMood_number(int mood_number) {
        this.mood_number = mood_number;
    }

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }
}
