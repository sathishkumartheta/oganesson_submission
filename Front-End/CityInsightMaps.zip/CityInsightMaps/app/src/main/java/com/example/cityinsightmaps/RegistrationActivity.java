package com.example.cityinsightmaps;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;
import java.util.HashMap;
import java.util.Map;
public class RegistrationActivity extends AppCompatActivity{
    private EditText emailEditText, passwordEditText, nameEditText, DescribeText; // Added nameEditText
    private Button registerButton;
    private ProgressBar progressBar;

    private FirebaseAuth mAuth;
    private FirebaseFirestore db;

    private static final String TAG = "RegistrationActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration); // Create this layout file

        mAuth = FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance();

        emailEditText = findViewById(R.id.emailEditText);
        DescribeText = findViewById(R.id.editTextEventDescription);
        passwordEditText = findViewById(R.id.passwordEditText);
        nameEditText = findViewById(R.id.nameEditText1); // Initialize nameEditText
        registerButton = findViewById(R.id.registerButton1);
        progressBar = findViewById(R.id.progressBar);
//editTextEventDescription
        registerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                registerUser();
            }
        });
    }

    private void registerUser() {
        String email = emailEditText.getText().toString().trim();
        String password = passwordEditText.getText().toString().trim();
        String name = nameEditText.getText().toString().trim(); // Get name input
        String describe = DescribeText.getText().toString().trim(); // Get name input
        if (TextUtils.isEmpty(email)) {
            emailEditText.setError("Email is required.");
            return;
        }
        if (TextUtils.isEmpty(password)) {
            passwordEditText.setError("Password is required.");
            return;
        }
        if (password.length() < 6) {
            passwordEditText.setError("Password must be at least 6 characters.");
            return;
        }
        if (TextUtils.isEmpty(name)) { // Validate name input
            nameEditText.setError("Name is required.");
            return;
        }
        if (TextUtils.isEmpty(describe)) { // Validate name input
            DescribeText.setError("Description is required.");
            return;
        }
        progressBar.setVisibility(View.VISIBLE);

        mAuth.createUserWithEmailAndPassword(email, password)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            Log.d(TAG, "createUserWithEmail:success");
                            FirebaseUser user = mAuth.getCurrentUser();
                            if (user != null) {
                                // Pass name to addUserToFirestore
                                addUserToFirestore(user.getUid(), user.getEmail(), name,describe);
                            }
                        } else {
                            progressBar.setVisibility(View.GONE);
                            Log.w(TAG, "createUserWithEmail:failure", task.getException());
                            Toast.makeText(RegistrationActivity.this, "Registration failed: " + task.getException().getMessage(),
                                    Toast.LENGTH_SHORT).show();
                        }
                    }
                });
    }

    // Updated method signature to accept name
    private void addUserToFirestore(String uid, String email, String name, String describe) {
        Map<String, Object> user = new HashMap<>();
        user.put("email", email);
        user.put("name", name); // Use the provided name
        user.put("describe", describe); // Use the provided name
        user.put("joined_date", System.currentTimeMillis()); // Current timestamp

        db.collection("users").document(uid)
                .set(user)
                .addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        progressBar.setVisibility(View.GONE);
                        if (task.isSuccessful()) {
                            Log.d(TAG, "User document added to Firestore.");
                            Toast.makeText(RegistrationActivity.this, "Registration successful!", Toast.LENGTH_SHORT).show();
                            // Navigate to MapsActivity
                            Intent intent = new Intent(RegistrationActivity.this, MapsActivity.class);
                            startActivity(intent);
                            finish(); // Close RegistrationActivity
                        } else {
                            Log.e(TAG, "Error adding user document to Firestore: ", task.getException());
                            Toast.makeText(RegistrationActivity.this, "Registration successful, but failed to update user data. Please try logging in.", Toast.LENGTH_LONG).show();
                            // Optionally sign out the user from Auth if Firestore update fails
                            mAuth.signOut();
                            // Redirect to LoginActivity
                            Intent intent = new Intent(RegistrationActivity.this, LoginActivity.class);
                            startActivity(intent);
                            finish();
                        }
                    }
                });
    }
}
